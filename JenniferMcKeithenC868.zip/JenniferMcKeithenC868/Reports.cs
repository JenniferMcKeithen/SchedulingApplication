﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Globalization;

namespace JenniferMcKeithenC969
{
    public partial class Reports : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
        DataTable appointmentTable = new DataTable();
        DateTime currentDate;
        

        public Reports()
        {
            InitializeComponent();
            
            currentDate = DateTime.Now;
            displayByMonth();
            PopulateAppointments();
            PopulateAppointmentLocation();

            if (CultureInfo.CurrentCulture.LCID == 1036)
            {
                appointmentsLabel.Text = "Mon planning par mois";
                appTypeLabel.Text = "Rendez-vous par catégorie";
                appLocationLabel.Text = "Rendez-vous par ville";
                mainMenu.Text = "Menu principal";
            }
        }

        private void displayByMonth()
        {

            appointmentTable.Clear();
            int month = currentDate.Month;
            int year = currentDate.Year;
            int day = currentDate.Day;
            string startDate = year.ToString() + "-" + month.ToString() + "-01";

            DateTime tempDate = Convert.ToDateTime(startDate);
            switch (month)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                    day = 31;
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    day = 30;
                    break;
                default:
                    day = 29;
                    break;
            }

            string endDate = year.ToString() + "-" + month.ToString() + "-" + day.ToString();

            string s = "SELECT customer.customerName, appointment.location, appointment.type, appointment.start, appointment.end FROM customer INNER JOIN appointment ON customer.customerId=appointment.customerId WHERE start BETWEEN '" + startDate + "' AND '" + endDate + "'";


            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = new MySqlCommand(s, connection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);

            adapter.Fill(appointmentTable);
            scheduleGridView.DataSource = appointmentTable;
            connection.Close();
        }

        private void PopulateAppointments()
        {
            
            MySqlConnection connection = new MySqlConnection(connectionString);

            string SqlQuery = "SELECT appointment.appointmentId, customer.customerName, appointment.location, appointment.type, appointment.start, appointment.end FROM customer INNER JOIN appointment ON customer.customerId=appointment.customerId";

            MySqlCommand command = new MySqlCommand(SqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable appointmentTable2 = new DataTable();
            adapter.Fill(appointmentTable2);
            appointTypeGrid.DataSource = appointmentTable2;
            connection.Close();
        }

        private void PopulateAppointmentLocation()
        {
            MySqlConnection connection = new MySqlConnection(connectionString);

            string SqlQuery = "SELECT appointment.appointmentId, customer.customerName, appointment.location, appointment.type, appointment.start, appointment.end FROM customer INNER JOIN appointment ON customer.customerId=appointment.customerId";

            MySqlCommand command = new MySqlCommand(SqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable appointmentTable4 = new DataTable();
            adapter.Fill(appointmentTable4);
            appointLocationGrid.DataSource = appointmentTable4;
            connection.Close();
        }

        private void mainMenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            WelcomeForm welcome = new WelcomeForm();
            welcome.Show();
        }

     
        private void scheduleGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value is DateTime)
            {
                var date = (DateTime)e.Value;
                var localDate = date.ToLocalTime();
                e.Value = localDate;

            }
        }

        private void scheduleGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            scheduleGridView.ClearSelection();
        }

        private void appointTypeChoose_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            string AppointmentsByType = "SELECT appointment.appointmentId, customer.customerName, appointment.location, appointment.type, appointment.start, appointment.end FROM customer INNER JOIN appointment ON customer.customerId = appointment.customerId WHERE appointment.type = '" + appointTypeChoose.Text + "'";

            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = new MySqlCommand(AppointmentsByType, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable appointmentTable3 = new DataTable();
            adapter.Fill(appointmentTable3);
            appointTypeGrid.DataSource = appointmentTable3;
            connection.Close();
        }

        private void locationChoose_SelectedIndexChanged(object sender, EventArgs e)
        {
            string AppointmentsByType = "SELECT appointment.appointmentId, customer.customerName, appointment.location, appointment.type, appointment.start, appointment.end FROM customer INNER JOIN appointment ON customer.customerId = appointment.customerId WHERE appointment.location = '" + locationChoose.Text + "'";

            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = new MySqlCommand(AppointmentsByType, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable appointmentTable5 = new DataTable();
            adapter.Fill(appointmentTable5);
            appointLocationGrid.DataSource = appointmentTable5;
            connection.Close();
        }

        private void appointTypeGrid_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value is DateTime)
            {
                var date = (DateTime)e.Value;
                var localDate = date.ToLocalTime();
                e.Value = localDate;

            }
        }

        private void appointLocationGrid_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value is DateTime)
            {
                var date = (DateTime)e.Value;
                var localDate = date.ToLocalTime();
                e.Value = localDate;

            }
        }

        private void monthCalendar_DateChanged(object sender, DateRangeEventArgs e)
        {
            string AppointmentsByType = "SELECT customer.customerName, appointment.location, appointment.type, appointment.start, appointment.end FROM customer INNER JOIN appointment ON customer.customerId=appointment.customerId WHERE '" + e.ToString() + "' BETWEEN appointment.start AND appointment.end";
            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = new MySqlCommand(AppointmentsByType, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable appointmentTable6 = new DataTable();
            adapter.Fill(appointmentTable6);
            scheduleGridView.DataSource = appointmentTable6;
            connection.Close();
        }
    }
}
