﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Globalization;


namespace JenniferMcKeithenC969
{
    public partial class WelcomeForm : Form
    {

        public int idSelectedCustomer = -1;
        public int idSelectedAppointment = -1;
        DataTable appointmentTable = new DataTable();
        public static int idx = 0;

        public WelcomeForm()
        {
            InitializeComponent();
            customerGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            AppointmentsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            if (CultureInfo.CurrentCulture.LCID == 1036)
                 {
            //Supporting French language users
                WelcomeHeader.Text = "Bienvenue, " + UpdateInfo.loggedInUser + " !";
                CustomerLabel.Text = "Clients";
                searchCustBtn.Text = "Chercher";
                addCustBtn.Text = "Ajouter client";
                updateCustBtn.Text = "Mettre à jour client";
                deleteCustBtn.Text = "Supprimer client";
                addAppointmentBtn.Text = "Ajouter rendez-vous";
                updateApptBtn.Text = "Changer rendez-vous";
                deleteApptBtn.Text = "Supprimer rendez-vous";
                myAppointments.Text = "Rendez-vous";
                byWeekLink.Text = "Voir calendrier";
                reportsButton.Text = "Voir rapports";
                ExitAppBtn.Text = "Sortir";
                 }

            else { 
                WelcomeHeader.Text = "Welcome, " + UpdateInfo.loggedInUser + "!"; 
                 }
            
         
            appointNotification.Visible = false;

            appointmentReminder();
        }

        private void WelcomeForm_Load(object sender, EventArgs e)
        {
            PopulateCustomers();
            PopulateAppointments();
            appointmentReminder();
        }

         public void appointmentReminder()
        {

            DateTime appointmentStart;
            DateTime loginTime = DateTime.Now;

            string connectionString;
            connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(connectionString);

            string sqlQuery = "SELECT start FROM appointment";

            MySqlCommand command = new MySqlCommand(sqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable appointmentCheckTable = new DataTable();
            adapter.Fill(appointmentCheckTable);

            foreach (DataColumn col in appointmentCheckTable.Columns)
            {
                foreach (DataRow row in appointmentCheckTable.Rows)
                {
                    appointmentStart = Convert.ToDateTime(row[col].ToString()).ToLocalTime();
                    TimeSpan timespan = appointmentStart - loginTime;

                    if (timespan.TotalMinutes <= 15 && timespan.TotalMinutes > 1)
                    {
                        appointNotification.Visible = true;

                        if (CultureInfo.CurrentCulture.LCID == 1036) 
                        {
                            appointNotification.Text = "Vous avez un rendez-vous à venir.";
                        }
                        else
                        {
                            appointNotification.Text = "You have an upcoming appointment.";
                        }
                    }
                }
            }
            connection.Close();
        }
            

        private void PopulateCustomers()
        {
            string connectionString;
            connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(connectionString);

            string sqlQuery = "SELECT customer.customerId, customer.customerName, address.addressId, address.address, address.phone, city.city FROM customer INNER JOIN address ON customer.addressID=address.addressID INNER JOIN city ON address.cityId=city.cityId";

            MySqlCommand command = new MySqlCommand(sqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable customerTable = new DataTable();
            adapter.Fill(customerTable);
            customerGridView.DataSource = customerTable;
            connection.Close();
        }

        private void PopulateAppointments()
        {
            string connectionString;
            connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(connectionString);

            string sqlQuery = "SELECT appointment.appointmentId, customer.customerName, appointment.location, appointment.type, appointment.start, appointment.end, user.userName FROM customer INNER JOIN appointment ON customer.customerId=appointment.customerId INNER JOIN user ON appointment.userId=user.userId";

            MySqlCommand command = new MySqlCommand(sqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            
            adapter.Fill(appointmentTable);
            AppointmentsGrid.DataSource = appointmentTable;
            connection.Close();
        }



        private void addCustBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Add_Customer addCust = new Add_Customer();
            addCust.Show();
        }

        private void addAppointmentBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddAppointment addAppointment = new AddAppointment();
            addAppointment.Show();
        }


        private void byWeekLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            AllAppointments allAppointments = new AllAppointments();
            allAppointments.Show();
        }

        private void AppointmentsGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            idSelectedAppointment = e.RowIndex;
        }

        private void customerGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            idSelectedCustomer = e.RowIndex;
        }

        private void deleteCustBtn_Click(object sender, EventArgs e)
        {

                MySqlConnection connect = new MySqlConnection();
                MySqlCommand delcomm = new MySqlCommand();

                connect.ConnectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;

                delcomm.CommandText = "DELETE customer, address FROM customer INNER JOIN address ON customer.addressId = address.addressId WHERE customerId ='" + customerGridView.SelectedRows[0].Cells[0].Value.ToString() + "'"; ;
           
                connect.Open();
                delcomm.Connection = connect;
                delcomm.ExecuteNonQuery();

                connect.Close();

                customerGridView.Rows.RemoveAt(customerGridView.SelectedRows[0].Index);

            if (CultureInfo.CurrentCulture.LCID == 1036)
            {
                MessageBox.Show("Client supprimé.");
            }

            else { MessageBox.Show("Customer deleted."); }
          
        }


        private void updateApptBtn_Click(object sender, EventArgs e)
        {
            if (idSelectedAppointment < 0)
            {
                if (CultureInfo.CurrentCulture.LCID == 1036)
                {
                    MessageBox.Show("Veuillez sélectionner un rendez-vous à modifier.");
                }

                else { MessageBox.Show("Please select an appointment to modify."); }
            }
            else
            {
                int i = AppointmentsGrid.SelectedCells[0].RowIndex;
                UpdateInfo.appointmentId = Convert.ToInt32(AppointmentsGrid.Rows[i].Cells[0].Value.ToString());
                UpdateInfo.customerFullName = AppointmentsGrid.Rows[i].Cells[1].Value.ToString();
                UpdateInfo.AppointmentLocation = AppointmentsGrid.Rows[i].Cells[2].Value.ToString();
                UpdateInfo.AppointType = AppointmentsGrid.Rows[i].Cells[3].Value.ToString();
                UpdateInfo.AppointmentStartDate = Convert.ToDateTime(AppointmentsGrid.Rows[i].Cells[4].Value.ToString());
                UpdateInfo.AppointmentEndDate = Convert.ToDateTime(AppointmentsGrid.Rows[i].Cells[5].Value.ToString());
                UpdateInfo.AppointmentStartTime = Convert.ToDateTime(AppointmentsGrid.Rows[i].Cells[4].Value.ToString());
                UpdateInfo.AppointmentEndTime = Convert.ToDateTime(AppointmentsGrid.Rows[i].Cells[5].Value.ToString());
                UpdateInfo.consultantName = AppointmentsGrid.Rows[i].Cells[6].Value.ToString();

                this.Hide();
                UpdateAppointment f = new UpdateAppointment();
                f.Show();
            }
        }

        private void updateCustBtn_Click(object sender, EventArgs e)
        {

            if (idSelectedCustomer < 0)
            {
                if (CultureInfo.CurrentCulture.LCID == 1036)
                {
                    MessageBox.Show("Veuillez sélectionner un client à modifier.");
                }

                else { MessageBox.Show("Please select a customer to modify."); }
            }
            else
            {
                int i = customerGridView.SelectedCells[0].RowIndex;
                UpdateInfo.customerID = Convert.ToInt32(customerGridView.Rows[i].Cells[0].Value.ToString());
                UpdateInfo.customerFullName = customerGridView.Rows[i].Cells[1].Value.ToString();
                UpdateInfo.custAddressID = Convert.ToInt32(customerGridView.Rows[i].Cells[2].Value.ToString());
                UpdateInfo.customerAddress = customerGridView.Rows[i].Cells[3].Value.ToString();
                UpdateInfo.customerPhoneNum = customerGridView.Rows[i].Cells[4].Value.ToString();
                UpdateInfo.customerCity = customerGridView.Rows[i].Cells[5].Value.ToString();

                this.Hide();
                UpdateCustomer f = new UpdateCustomer();
                f.Show();
            }
        }



        private void ExitAppBtn_Click(object sender, EventArgs e) => Application.Exit();   //Lambda expression to exit application faster.


        private void deleteApptBtn_Click(object sender, EventArgs e)
        {
            
                MySqlConnection connect = new MySqlConnection();
                MySqlCommand delcomm = new MySqlCommand();

                connect.ConnectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;

                delcomm.CommandText = "DELETE FROM appointment WHERE appointmentId ='" + AppointmentsGrid.SelectedRows[0].Cells[0].Value + "'"; ;
                connect.Open();
                delcomm.Connection = connect;
                delcomm.ExecuteNonQuery();

                connect.Close();

                AppointmentsGrid.Rows.RemoveAt(AppointmentsGrid.SelectedRows[0].Index);

            if (CultureInfo.CurrentCulture.LCID == 1036)
            {
                MessageBox.Show("Rendez-vous supprimé.");
            }

            else { MessageBox.Show("Appointment deleted."); }
            
        }


        private void AppointmentsGrid_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {

            if (e.Value is DateTime)
            {
                var date = (DateTime)e.Value;
                var localDate = date.ToLocalTime();
                e.Value = localDate;
               
            }
        }

        private void reportsButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Reports f = new Reports();
            f.Show();
        }



        private void searchCustBtn_Click(object sender, EventArgs e)
        {
            string connectionString;
            connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(connectionString);

            string sqlQuery = "SELECT customer.customerId, customer.customerName, address.addressId, address.address, address.phone, city.city FROM customer INNER JOIN address ON customer.addressID=address.addressID INNER JOIN city ON address.cityId=city.cityId WHERE customer.customerName LIKE '" + searchCustomerBox.Text + "%'";

            MySqlCommand command = new MySqlCommand(sqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable customerTable = new DataTable();
            adapter.Fill(customerTable);
            customerGridView.DataSource = customerTable;
            connection.Close();
        }
    }
}
