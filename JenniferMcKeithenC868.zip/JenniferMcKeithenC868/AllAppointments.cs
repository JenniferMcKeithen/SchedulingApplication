﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Globalization;

namespace JenniferMcKeithenC969
{
    public partial class AllAppointments : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
        DataTable appointmentTable = new DataTable();
        DateTime currentDate;


        public AllAppointments()
        {
            InitializeComponent();
            currentDate = DateTime.Now;
            monthCalendar.AddBoldedDate(currentDate);
            radioViewMonth.Checked = true;
            dataGridAllAppts.DataSource = appointmentTable;
            alertMessage.Visible = false;

            if (CultureInfo.CurrentCulture.LCID == 1036)
            {
                radioViewWeek.Text = "Vue par semaine";
                radioViewMonth.Text = "Vue par mois";
                MainMenuBtn.Text = "Menu principal";
            }
        }

        private void AllAppointments_Load(object sender, EventArgs e)
        {
           PopulateAppointments();
        }

        private void PopulateAppointments()
        {
            string connectionString;
            connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(connectionString);

            string sqlQuery = "SELECT customer.customerName, appointment.location, appointment.type, appointment.start, user.userName FROM customer INNER JOIN appointment ON customer.customerId=appointment.customerId INNER JOIN user ON appointment.userId=user.userId";

            MySqlCommand command = new MySqlCommand(sqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable appointmentTable = new DataTable();
            adapter.Fill(appointmentTable);
            dataGridAllAppts.DataSource = appointmentTable;
            connection.Close();
        }

        private void radioViewMonth_CheckedChanged(object sender, EventArgs e) => displayByMonth(); // Lambda expression to display appointments by month. Code is easier to read.
        


        private void radioViewWeek_CheckedChanged(object sender, EventArgs e) => displayByWeek(); // Lambda expression to display appointments by week. Code is easier to read.


        private void displayByMonth()
        {
            try
            {
                monthCalendar.RemoveAllBoldedDates();
                appointmentTable.Clear();
                int month = currentDate.Month;
                int year = currentDate.Year;
                int day = currentDate.Day;
                string startDate = year.ToString() + "-" + month.ToString() + "-01";

                DateTime tempDate = Convert.ToDateTime(startDate);
                switch (month)
                {
                    case 1:
                    case 3:
                    case 5:
                    case 7:
                    case 8:
                    case 10:
                        day = 31;
                        break;
                    case 4:
                    case 6:
                    case 9:
                    case 11:
                        day = 30;
                        break;
                    default:
                        day = 29;
                        break;
                }

                string endDate = year.ToString() + "-" + month.ToString() + "-" + day.ToString();

                for (int i = 0; i < day; i++)
                {
                    monthCalendar.AddBoldedDate(tempDate.AddDays(i));
                }
                monthCalendar.UpdateBoldedDates();

                string s = "SELECT customer.customerName, appointment.location, appointment.type, appointment.start FROM customer INNER JOIN appointment ON customer.customerId=appointment.customerId WHERE start BETWEEN '" + startDate + "' AND '" + endDate + "'";
                MySqlConnection connection = new MySqlConnection(connectionString);
                MySqlCommand command = new MySqlCommand(s, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                adapter.Fill(appointmentTable);
                dataGridAllAppts.DataSource = appointmentTable;
                connection.Close();
            }
            catch
            {
                return;
            }
        }

        private void displayByWeek()
        {
            try
            {
                monthCalendar.RemoveAllBoldedDates();
                appointmentTable.Clear();
                int month = currentDate.Month;
                int year = currentDate.Year;
                int day = currentDate.Day;

                int dayOfWeek = (int)currentDate.DayOfWeek;
                string startDate = year.ToString() + "-" + month.ToString() + "-" + (day - dayOfWeek).ToString();

                DateTime tempDate = Convert.ToDateTime(startDate);
                for (int i = 0; i < 7; i++)
                {
                    monthCalendar.AddBoldedDate(tempDate.AddDays(i));
                }
                monthCalendar.UpdateBoldedDates();

                string endDate = year.ToString() + "-" + month.ToString() + "-" + currentDate.AddDays(7 - dayOfWeek - 1).Day.ToString();
                string dispWeek = "SELECT customer.customerName, appointment.location, appointment.type, appointment.start FROM customer INNER JOIN appointment ON customer.customerId=appointment.customerId WHERE start BETWEEN '" + startDate + "' AND '" + endDate + "'";
                MySqlConnection connection = new MySqlConnection(connectionString);
                MySqlCommand command = new MySqlCommand(dispWeek, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                adapter.Fill(appointmentTable);
                dataGridAllAppts.DataSource = appointmentTable;
                connection.Close();
            }
            catch
            {
                return;
            }
        }



        private void MainMenuBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            WelcomeForm welcome = new WelcomeForm();
            welcome.Show();
        }

  

        private void dataGridAllAppts_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e) => dataGridAllAppts.ClearSelection(); //Lambda expression to clear the current selection in the dataGridView.
        

        private void monthCalendar_DateSelected(object sender, DateRangeEventArgs e)
        {
            currentDate = e.Start;
            if (radioViewMonth.Checked)
            {
                displayByMonth();
            }
            else
            {
                displayByWeek();
            }
        }

        private void dataGridAllAppts_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value is DateTime)
            {
                var date = (DateTime)e.Value;
                var localDate = date.ToLocalTime();
                e.Value = localDate;

            }
        }
    }
}
