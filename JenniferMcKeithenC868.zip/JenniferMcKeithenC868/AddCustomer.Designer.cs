﻿namespace JenniferMcKeithenC969
{
    partial class Add_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IDtextBox = new System.Windows.Forms.TextBox();
            this.FNametextBox = new System.Windows.Forms.TextBox();
            this.LNametextBox = new System.Windows.Forms.TextBox();
            this.Address1Box = new System.Windows.Forms.TextBox();
            this.CountryBox = new System.Windows.Forms.TextBox();
            this.PhoneBox = new System.Windows.Forms.TextBox();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.CustID = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.Label();
            this.LastName = new System.Windows.Forms.Label();
            this.Address1 = new System.Windows.Forms.Label();
            this.City = new System.Windows.Forms.Label();
            this.Country = new System.Windows.Forms.Label();
            this.PhoneNum = new System.Windows.Forms.Label();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.CityBox = new System.Windows.Forms.ComboBox();
            this.messageLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // IDtextBox
            // 
            this.IDtextBox.Enabled = false;
            this.IDtextBox.Location = new System.Drawing.Point(309, 52);
            this.IDtextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.IDtextBox.Name = "IDtextBox";
            this.IDtextBox.Size = new System.Drawing.Size(161, 20);
            this.IDtextBox.TabIndex = 0;
            // 
            // FNametextBox
            // 
            this.FNametextBox.Location = new System.Drawing.Point(309, 94);
            this.FNametextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.FNametextBox.Name = "FNametextBox";
            this.FNametextBox.Size = new System.Drawing.Size(161, 20);
            this.FNametextBox.TabIndex = 1;
            this.FNametextBox.TextChanged += new System.EventHandler(this.FNametextBox_TextChanged);
            // 
            // LNametextBox
            // 
            this.LNametextBox.Location = new System.Drawing.Point(309, 136);
            this.LNametextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LNametextBox.Name = "LNametextBox";
            this.LNametextBox.Size = new System.Drawing.Size(161, 20);
            this.LNametextBox.TabIndex = 2;
            this.LNametextBox.TextChanged += new System.EventHandler(this.LNametextBox_TextChanged);
            // 
            // Address1Box
            // 
            this.Address1Box.Location = new System.Drawing.Point(309, 178);
            this.Address1Box.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Address1Box.Name = "Address1Box";
            this.Address1Box.Size = new System.Drawing.Size(161, 20);
            this.Address1Box.TabIndex = 3;
            this.Address1Box.TextChanged += new System.EventHandler(this.Address1Box_TextChanged);
            // 
            // CountryBox
            // 
            this.CountryBox.Enabled = false;
            this.CountryBox.Location = new System.Drawing.Point(309, 260);
            this.CountryBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.CountryBox.Name = "CountryBox";
            this.CountryBox.Size = new System.Drawing.Size(161, 20);
            this.CountryBox.TabIndex = 5;
            this.CountryBox.TextChanged += new System.EventHandler(this.CountryBox_TextChanged);
            // 
            // PhoneBox
            // 
            this.PhoneBox.Location = new System.Drawing.Point(309, 308);
            this.PhoneBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PhoneBox.Name = "PhoneBox";
            this.PhoneBox.Size = new System.Drawing.Size(161, 20);
            this.PhoneBox.TabIndex = 6;
            this.PhoneBox.TextChanged += new System.EventHandler(this.PhoneBox_TextChanged);
            // 
            // SaveBtn
            // 
            this.SaveBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.SaveBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveBtn.Location = new System.Drawing.Point(78, 360);
            this.SaveBtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(160, 42);
            this.SaveBtn.TabIndex = 7;
            this.SaveBtn.Text = "Save";
            this.SaveBtn.UseVisualStyleBackColor = false;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // CustID
            // 
            this.CustID.AutoSize = true;
            this.CustID.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustID.Location = new System.Drawing.Point(101, 54);
            this.CustID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.CustID.Name = "CustID";
            this.CustID.Size = new System.Drawing.Size(43, 18);
            this.CustID.TabIndex = 8;
            this.CustID.Text = "ID #";
            // 
            // FirstName
            // 
            this.FirstName.AutoSize = true;
            this.FirstName.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstName.Location = new System.Drawing.Point(96, 99);
            this.FirstName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(101, 18);
            this.FirstName.TabIndex = 9;
            this.FirstName.Text = "First Name";
            // 
            // LastName
            // 
            this.LastName.AutoSize = true;
            this.LastName.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastName.Location = new System.Drawing.Point(96, 138);
            this.LastName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(96, 18);
            this.LastName.TabIndex = 10;
            this.LastName.Text = "Last Name";
            // 
            // Address1
            // 
            this.Address1.AutoSize = true;
            this.Address1.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address1.Location = new System.Drawing.Point(96, 180);
            this.Address1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Address1.Name = "Address1";
            this.Address1.Size = new System.Drawing.Size(78, 18);
            this.Address1.TabIndex = 11;
            this.Address1.Text = "Address";
            // 
            // City
            // 
            this.City.AutoSize = true;
            this.City.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.City.Location = new System.Drawing.Point(96, 219);
            this.City.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(42, 18);
            this.City.TabIndex = 12;
            this.City.Text = "City";
            // 
            // Country
            // 
            this.Country.AutoSize = true;
            this.Country.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Country.Location = new System.Drawing.Point(96, 260);
            this.Country.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Country.Name = "Country";
            this.Country.Size = new System.Drawing.Size(76, 18);
            this.Country.TabIndex = 13;
            this.Country.Text = "Country";
            this.Country.Click += new System.EventHandler(this.Country_Click);
            // 
            // PhoneNum
            // 
            this.PhoneNum.AutoSize = true;
            this.PhoneNum.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNum.Location = new System.Drawing.Point(96, 307);
            this.PhoneNum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PhoneNum.Name = "PhoneNum";
            this.PhoneNum.Size = new System.Drawing.Size(60, 18);
            this.PhoneNum.TabIndex = 14;
            this.PhoneNum.Text = "Phone";
            // 
            // CancelBtn
            // 
            this.CancelBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.CancelBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelBtn.Location = new System.Drawing.Point(309, 360);
            this.CancelBtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(160, 42);
            this.CancelBtn.TabIndex = 15;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = false;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // CityBox
            // 
            this.CityBox.FormattingEnabled = true;
            this.CityBox.Items.AddRange(new object[] {
            "New York",
            "Phoenix",
            "Los Angeles",
            "Toronto",
            "Vancouver",
            "London",
            "Oslo",
            "Paris"});
            this.CityBox.Location = new System.Drawing.Point(309, 216);
            this.CityBox.Name = "CityBox";
            this.CityBox.Size = new System.Drawing.Size(161, 21);
            this.CityBox.TabIndex = 16;
            this.CityBox.SelectedIndexChanged += new System.EventHandler(this.CityBox_SelectedIndexChanged);
            // 
            // messageLabel
            // 
            this.messageLabel.AutoSize = true;
            this.messageLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.messageLabel.Location = new System.Drawing.Point(75, 461);
            this.messageLabel.Name = "messageLabel";
            this.messageLabel.Size = new System.Drawing.Size(61, 18);
            this.messageLabel.TabIndex = 17;
            this.messageLabel.Text = "label1";
            // 
            // Add_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(707, 558);
            this.Controls.Add(this.messageLabel);
            this.Controls.Add(this.CityBox);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.PhoneNum);
            this.Controls.Add(this.Country);
            this.Controls.Add(this.City);
            this.Controls.Add(this.Address1);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.CustID);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.PhoneBox);
            this.Controls.Add(this.CountryBox);
            this.Controls.Add(this.Address1Box);
            this.Controls.Add(this.LNametextBox);
            this.Controls.Add(this.FNametextBox);
            this.Controls.Add(this.IDtextBox);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MinimumSize = new System.Drawing.Size(723, 597);
            this.Name = "Add_Customer";
            this.Text = "Add  Customer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox IDtextBox;
        private System.Windows.Forms.TextBox FNametextBox;
        private System.Windows.Forms.TextBox LNametextBox;
        private System.Windows.Forms.TextBox Address1Box;
        private System.Windows.Forms.TextBox CountryBox;
        private System.Windows.Forms.TextBox PhoneBox;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.Label CustID;
        private System.Windows.Forms.Label FirstName;
        private System.Windows.Forms.Label LastName;
        private System.Windows.Forms.Label Address1;
        private System.Windows.Forms.Label City;
        private System.Windows.Forms.Label Country;
        private System.Windows.Forms.Label PhoneNum;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.ComboBox CityBox;
        private System.Windows.Forms.Label messageLabel;
    }
}