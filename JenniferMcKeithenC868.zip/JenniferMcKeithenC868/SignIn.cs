﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Globalization;
using System.IO;
using System.Runtime.Serialization;

namespace JenniferMcKeithenC969
{
    public partial class SignInForm : Form
    {
        public string errorControlMess = "Incorrect username and password.";
        
        public string filename = "UserActivity.txt";
        public string LoginSuccessful;
        public string UserName;
        public DateTime LoginTime;


        public SignInForm()
        {
            InitializeComponent();

            // Supporting French-speaking users in France.
            if (CultureInfo.CurrentCulture.LCID == 1036)
            {
                userName.Text = "Nom d'utilisateur";
                passWord.Text = "Mot de passe";
                signInButton.Text = "Se connecter";
                messageLabel.Text = "Veuillez entrer votre nom et votre mot de passe.";
                errorControlMess = "Nom d'utilisateur et mot de passe incorrects.";
            }
        }

        private void TrackUserActivity() // Records timestamps for user log-ins in a .txt file.
        {
            UserName = UserNameText.Text;
            LoginTime = DateTime.Now;
            using (FileStream fileStream = new FileStream(filename, FileMode.Append, FileAccess.Write))
            using (StreamWriter streamWriter = new StreamWriter(fileStream))
            {
                streamWriter.WriteLine(UserName + " " + LoginTime + " " + LoginSuccessful);
            }
        }

        private void signInButton_Click(object sender, EventArgs e)
        {
            string ConnectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(ConnectionString);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT `userName`, `password` FROM `user` " +
                                                             "WHERE `userName` = '" + UserNameText.Text + "' AND `password` = '" + PasswordTextBox.Text + "'", connection);
            DataTable table = new DataTable();
            adapter.Fill(table);

            //Checking to make sure the user enters the correct login credentials
            if (table.Rows.Count <= 0)
            {
                messageLabel.Text = errorControlMess;
                messageLabel.ForeColor = Color.Red;
                LoginSuccessful = "Login unsuccessful.";
            }
            else 
            {
                LoginSuccessful = "Login successful.";
                UpdateInfo.loggedInUser = UserNameText.Text;
                this.Hide();
                WelcomeForm welcome = new WelcomeForm();
                welcome.Show();
            }

            TrackUserActivity();
            connection.Close();
        }

        private void UserNameText_TextChanged(object sender, EventArgs e)
        {

        }

        private void PasswordTextBox_TextChanged(object sender, EventArgs e)
        {

        }

      
    }
}
