﻿namespace JenniferMcKeithenC969
{
    partial class UpdateAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customerDataGrid = new System.Windows.Forms.DataGridView();
            this.CustomersLabel = new System.Windows.Forms.Label();
            this.custBox = new System.Windows.Forms.TextBox();
            this.customerLabel = new System.Windows.Forms.Label();
            this.startLabel = new System.Windows.Forms.Label();
            this.endLabel = new System.Windows.Forms.Label();
            this.locationLabel = new System.Windows.Forms.Label();
            this.typeLabel = new System.Windows.Forms.Label();
            this.startDatePicker = new System.Windows.Forms.DateTimePicker();
            this.endDatePicker = new System.Windows.Forms.DateTimePicker();
            this.LocationMenu = new System.Windows.Forms.ComboBox();
            this.AppointType = new System.Windows.Forms.ComboBox();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.appointIDBox = new System.Windows.Forms.TextBox();
            this.appId = new System.Windows.Forms.Label();
            this.messageLabel = new System.Windows.Forms.Label();
            this.AppointmentsGrid = new System.Windows.Forms.DataGridView();
            this.AppointmentsLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.customerDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AppointmentsGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // customerDataGrid
            // 
            this.customerDataGrid.BackgroundColor = System.Drawing.Color.IndianRed;
            this.customerDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customerDataGrid.Location = new System.Drawing.Point(415, 166);
            this.customerDataGrid.Name = "customerDataGrid";
            this.customerDataGrid.Size = new System.Drawing.Size(465, 152);
            this.customerDataGrid.TabIndex = 0;
            this.customerDataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.customerDataGrid_CellContentClick);
            // 
            // CustomersLabel
            // 
            this.CustomersLabel.AutoSize = true;
            this.CustomersLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomersLabel.Location = new System.Drawing.Point(412, 126);
            this.CustomersLabel.Name = "CustomersLabel";
            this.CustomersLabel.Size = new System.Drawing.Size(100, 18);
            this.CustomersLabel.TabIndex = 1;
            this.CustomersLabel.Text = "Customers";
            // 
            // custBox
            // 
            this.custBox.Enabled = false;
            this.custBox.Location = new System.Drawing.Point(137, 72);
            this.custBox.Name = "custBox";
            this.custBox.Size = new System.Drawing.Size(229, 20);
            this.custBox.TabIndex = 2;
            // 
            // customerLabel
            // 
            this.customerLabel.AutoSize = true;
            this.customerLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerLabel.Location = new System.Drawing.Point(11, 71);
            this.customerLabel.Name = "customerLabel";
            this.customerLabel.Size = new System.Drawing.Size(91, 18);
            this.customerLabel.TabIndex = 3;
            this.customerLabel.Text = "Customer";
            // 
            // startLabel
            // 
            this.startLabel.AutoSize = true;
            this.startLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startLabel.Location = new System.Drawing.Point(12, 141);
            this.startLabel.Name = "startLabel";
            this.startLabel.Size = new System.Drawing.Size(49, 18);
            this.startLabel.TabIndex = 4;
            this.startLabel.Text = "Start";
            // 
            // endLabel
            // 
            this.endLabel.AutoSize = true;
            this.endLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.endLabel.Location = new System.Drawing.Point(12, 206);
            this.endLabel.Name = "endLabel";
            this.endLabel.Size = new System.Drawing.Size(40, 18);
            this.endLabel.TabIndex = 5;
            this.endLabel.Text = "End";
            // 
            // locationLabel
            // 
            this.locationLabel.AutoSize = true;
            this.locationLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locationLabel.Location = new System.Drawing.Point(11, 271);
            this.locationLabel.Name = "locationLabel";
            this.locationLabel.Size = new System.Drawing.Size(80, 18);
            this.locationLabel.TabIndex = 6;
            this.locationLabel.Text = "Location";
            // 
            // typeLabel
            // 
            this.typeLabel.AutoSize = true;
            this.typeLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typeLabel.Location = new System.Drawing.Point(11, 345);
            this.typeLabel.Name = "typeLabel";
            this.typeLabel.Size = new System.Drawing.Size(50, 18);
            this.typeLabel.TabIndex = 7;
            this.typeLabel.Text = "Type";
            // 
            // startDatePicker
            // 
            this.startDatePicker.CustomFormat = "ddd, MMM dd, yyyy hh:mm:ss tt ";
            this.startDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.startDatePicker.Location = new System.Drawing.Point(138, 139);
            this.startDatePicker.Name = "startDatePicker";
            this.startDatePicker.Size = new System.Drawing.Size(229, 20);
            this.startDatePicker.TabIndex = 8;
            this.startDatePicker.ValueChanged += new System.EventHandler(this.startDatePicker_ValueChanged);
            // 
            // endDatePicker
            // 
            this.endDatePicker.CustomFormat = "ddd, MMM dd, yyyy hh:mm:ss tt ";
            this.endDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.endDatePicker.Location = new System.Drawing.Point(138, 204);
            this.endDatePicker.Name = "endDatePicker";
            this.endDatePicker.Size = new System.Drawing.Size(229, 20);
            this.endDatePicker.TabIndex = 9;
            this.endDatePicker.ValueChanged += new System.EventHandler(this.endDatePicker_ValueChanged);
            // 
            // LocationMenu
            // 
            this.LocationMenu.FormattingEnabled = true;
            this.LocationMenu.Items.AddRange(new object[] {
            "New York ",
            "Phoenix ",
            "Los Angeles ",
            "Toronto",
            "Vancouver",
            "London",
            "Oslo"});
            this.LocationMenu.Location = new System.Drawing.Point(138, 272);
            this.LocationMenu.Name = "LocationMenu";
            this.LocationMenu.Size = new System.Drawing.Size(229, 21);
            this.LocationMenu.TabIndex = 10;
            // 
            // AppointType
            // 
            this.AppointType.FormattingEnabled = true;
            this.AppointType.Items.AddRange(new object[] {
            "Scrum",
            "Presentation",
            "One on One",
            "Follow up"});
            this.AppointType.Location = new System.Drawing.Point(138, 342);
            this.AppointType.Name = "AppointType";
            this.AppointType.Size = new System.Drawing.Size(229, 21);
            this.AppointType.TabIndex = 11;
            // 
            // SaveBtn
            // 
            this.SaveBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.SaveBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveBtn.Location = new System.Drawing.Point(137, 634);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(228, 44);
            this.SaveBtn.TabIndex = 12;
            this.SaveBtn.Text = "Save";
            this.SaveBtn.UseVisualStyleBackColor = false;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.CancelBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelBtn.Location = new System.Drawing.Point(652, 634);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(228, 44);
            this.CancelBtn.TabIndex = 13;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = false;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // appointIDBox
            // 
            this.appointIDBox.Enabled = false;
            this.appointIDBox.Location = new System.Drawing.Point(137, 22);
            this.appointIDBox.Name = "appointIDBox";
            this.appointIDBox.Size = new System.Drawing.Size(229, 20);
            this.appointIDBox.TabIndex = 20;
            // 
            // appId
            // 
            this.appId.AutoSize = true;
            this.appId.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appId.Location = new System.Drawing.Point(11, 21);
            this.appId.Name = "appId";
            this.appId.Size = new System.Drawing.Size(84, 18);
            this.appId.TabIndex = 21;
            this.appId.Text = "Appt ID#";
            // 
            // messageLabel
            // 
            this.messageLabel.AutoSize = true;
            this.messageLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.messageLabel.Location = new System.Drawing.Point(12, 426);
            this.messageLabel.Name = "messageLabel";
            this.messageLabel.Size = new System.Drawing.Size(115, 18);
            this.messageLabel.TabIndex = 22;
            this.messageLabel.Text = "overlapMess";
            // 
            // AppointmentsGrid
            // 
            this.AppointmentsGrid.BackgroundColor = System.Drawing.Color.IndianRed;
            this.AppointmentsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AppointmentsGrid.Location = new System.Drawing.Point(415, 426);
            this.AppointmentsGrid.Name = "AppointmentsGrid";
            this.AppointmentsGrid.Size = new System.Drawing.Size(465, 152);
            this.AppointmentsGrid.TabIndex = 23;
            this.AppointmentsGrid.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.AppointmentsGrid_CellFormatting);
            // 
            // AppointmentsLabel
            // 
            this.AppointmentsLabel.AutoSize = true;
            this.AppointmentsLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AppointmentsLabel.Location = new System.Drawing.Point(412, 387);
            this.AppointmentsLabel.Name = "AppointmentsLabel";
            this.AppointmentsLabel.Size = new System.Drawing.Size(129, 18);
            this.AppointmentsLabel.TabIndex = 24;
            this.AppointmentsLabel.Text = "Appointments";
            // 
            // UpdateAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(984, 784);
            this.Controls.Add(this.AppointmentsLabel);
            this.Controls.Add(this.AppointmentsGrid);
            this.Controls.Add(this.messageLabel);
            this.Controls.Add(this.appId);
            this.Controls.Add(this.appointIDBox);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.AppointType);
            this.Controls.Add(this.LocationMenu);
            this.Controls.Add(this.endDatePicker);
            this.Controls.Add(this.startDatePicker);
            this.Controls.Add(this.typeLabel);
            this.Controls.Add(this.locationLabel);
            this.Controls.Add(this.endLabel);
            this.Controls.Add(this.startLabel);
            this.Controls.Add(this.customerLabel);
            this.Controls.Add(this.custBox);
            this.Controls.Add(this.CustomersLabel);
            this.Controls.Add(this.customerDataGrid);
            this.MinimumSize = new System.Drawing.Size(1000, 823);
            this.Name = "UpdateAppointment";
            this.Text = "UpdateAppointment";
            ((System.ComponentModel.ISupportInitialize)(this.customerDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AppointmentsGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView customerDataGrid;
        private System.Windows.Forms.Label CustomersLabel;
        private System.Windows.Forms.TextBox custBox;
        private System.Windows.Forms.Label customerLabel;
        private System.Windows.Forms.Label startLabel;
        private System.Windows.Forms.Label endLabel;
        private System.Windows.Forms.Label locationLabel;
        private System.Windows.Forms.Label typeLabel;
        private System.Windows.Forms.DateTimePicker startDatePicker;
        private System.Windows.Forms.DateTimePicker endDatePicker;
        private System.Windows.Forms.ComboBox LocationMenu;
        private System.Windows.Forms.ComboBox AppointType;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.TextBox appointIDBox;
        private System.Windows.Forms.Label appId;
        private System.Windows.Forms.Label messageLabel;
        private System.Windows.Forms.DataGridView AppointmentsGrid;
        private System.Windows.Forms.Label AppointmentsLabel;
    }
}