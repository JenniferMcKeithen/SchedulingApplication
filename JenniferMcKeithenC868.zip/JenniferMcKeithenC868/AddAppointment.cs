﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Globalization;

namespace JenniferMcKeithenC969
{
    public partial class AddAppointment : Form
    {
        public static int idSelectedCustomer;
 
        public AddAppointment()
        {
            InitializeComponent();
            PopulateCustomers();
            PopulateAppointments();
            messageLabel.Visible = false;
            CustomersGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; 

            idSelectedCustomer = -1;
            locationBox.SelectedIndex = -1;

            ValidateInfo();
            validTimes();
            SaveBtn.Enabled = false;

            if (CultureInfo.CurrentCulture.LCID == 1036)
            {
                CustomerName.Text = "Client";
                startLabel.Text = "Début";
                endLabel.Text = "Fin";
                Location.Text = "Ville";
                typeLabel.Text = "Catégorie";
                CustomersLabel.Text = "Clients";
                appoints.Text = "Rendez-vous";
                SaveBtn.Text = "Réserver";
                CancelBtn.Text = "Annuler";
            }
        }

        private void OutsideBusinessHours ()
        {
            DateTime openingTime = DateTime.Today.AddHours(8);
            DateTime closingTime = DateTime.Today.AddHours(17);

            if ((startTime.Value.TimeOfDay < openingTime.TimeOfDay) || (startTime.Value.TimeOfDay > closingTime.TimeOfDay) || (endTime.Value.TimeOfDay > closingTime.TimeOfDay) || (endTime.Value.TimeOfDay < openingTime.TimeOfDay))
            {
                messageLabel.Visible = true;

                if (CultureInfo.CurrentCulture.LCID == 1036)
                {
                    messageLabel.Text = "Veuillez sélectionner une heure entre les heures d'ouverture, de 9 h à 17 h.";
                }
                else
                {
                    messageLabel.Text = "Please select a time between business hours, 9am and 5pm.";
                }
                SaveBtn.Enabled = false;
            }
            else
            {
                messageLabel.Visible = false;
                SaveBtn.Enabled = true;
            }

        }

        private void validTimes ()
        {
            if (startTime.Value.TimeOfDay > endTime.Value.TimeOfDay || endTime.Value.TimeOfDay < startTime.Value.TimeOfDay)
            {
                messageLabel.Visible = true;
                if (CultureInfo.CurrentCulture.LCID == 1036)
                {
                    messageLabel.Text = "Veuillez sélectionner des heures valides.";
                }
                else
                {
                    messageLabel.Text = "Please select valid times.";
                }
                SaveBtn.Enabled = false;
            }
            
        }

        private void ValidateInfo()
        {
            if (idSelectedCustomer < 0)
            {
                messageLabel.Visible = true;
                if (CultureInfo.CurrentCulture.LCID == 1036)
                {
                    messageLabel.Text = "Veuillez remplir le formulaire.";
                }
                else
                {
                    messageLabel.Text = "Please complete the form.";
                }
                messageLabel.ForeColor = System.Drawing.Color.Red;
                CustomerTextBox.BackColor = System.Drawing.Color.Salmon;
                SaveBtn.Enabled = false;
            }
            if (locationBox.SelectedIndex < 0)
            {
                messageLabel.Visible = true;
                if (CultureInfo.CurrentCulture.LCID == 1036)
                {
                    messageLabel.Text = "Veuillez remplir le formulaire.";
                }
                else
                {
                    messageLabel.Text = "Please complete the form.";
                }
                messageLabel.ForeColor = System.Drawing.Color.Red;
                locationBox.BackColor = System.Drawing.Color.Salmon;
                SaveBtn.Enabled = false;
            }
            if (appointmentTypeBox.SelectedIndex < 0)
            {
                messageLabel.Visible = true;
                if (CultureInfo.CurrentCulture.LCID == 1036)
                {
                    messageLabel.Text = "Veuillez remplir le formulaire.";
                }
                else
                {
                    messageLabel.Text = "Please complete the form.";
                }
                messageLabel.ForeColor = System.Drawing.Color.Red;
                appointmentTypeBox.BackColor = System.Drawing.Color.Salmon;
                SaveBtn.Enabled = false;
            }

            if (idSelectedCustomer >= 0 && locationBox.SelectedIndex >= 0 && appointmentTypeBox.SelectedIndex >= 0)
            {
                SaveBtn.Enabled = true;
            }
        }

        private bool appointOverlap(DateTime sta, DateTime en, DateTime appointSt, DateTime appointEn)
        {
            if (sta < appointSt)
            {
                if (en < appointSt)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                if (sta > appointEn)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        private bool ValidateTimes()
        {

            string connectionString;
            connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(connectionString);

            string sqlQuery = "SELECT start, end FROM appointment";

            MySqlCommand command = new MySqlCommand(sqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable appointmentCheckTable = new DataTable();
            adapter.Fill(appointmentCheckTable);

            for (int idx = 0; idx < appointmentCheckTable.Rows.Count; idx++)
            {
                DateTime schedStart = TimeZoneInfo.ConvertTimeFromUtc((DateTime)appointmentCheckTable.Rows[idx]["start"], TimeZoneInfo.Local);
                DateTime schedEnd = TimeZoneInfo.ConvertTimeFromUtc((DateTime)appointmentCheckTable.Rows[idx]["end"], TimeZoneInfo.Local);
                DateTime myStart = startTime.Value;
                DateTime myEnd = endTime.Value;

                if (appointOverlap(schedStart, schedEnd, myStart, myEnd))
                {
                    if (CultureInfo.CurrentCulture.LCID == 1036)
                    {
                        messageLabel.Text = "Les heures / dates sélectionnées se chevauchent avec un rendez-vous existant.";
                    }
                    else
                    {
                        messageLabel.Text = "Times/Dates selected overlap with an existing appointment";
                    }
                    messageLabel.ForeColor = System.Drawing.Color.Red;
                    messageLabel.Visible = true;
                    SaveBtn.Enabled = false;
                    return true;
                }
            }

            connection.Close();
            return false;
        }


        private void PopulateCustomers()
        {
            string connectionString;
            connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(connectionString);

            string sqlQuery = "SELECT customer.customerId, customer.customerName, address.address, address.phone, city.city FROM customer INNER JOIN address ON customer.addressID=address.addressID INNER JOIN city ON address.cityId=city.cityId";

            MySqlCommand command = new MySqlCommand(sqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable appointmentTable = new DataTable();
            adapter.Fill(appointmentTable);
            CustomersGrid.DataSource = appointmentTable;
            connection.Close();

        }

        private void PopulateAppointments()
        {
            string connectionString;
            DataTable appointmentTable = new DataTable();
            connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(connectionString);

            string sqlQuery = "SELECT appointment.appointmentId, customer.customerName, appointment.location, appointment.type, appointment.start, appointment.end, user.userName FROM customer INNER JOIN appointment ON customer.customerId=appointment.customerId INNER JOIN user ON appointment.userId=user.userId";

            MySqlCommand command = new MySqlCommand(sqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);

            adapter.Fill(appointmentTable);
            AppointmentsGrid.DataSource = appointmentTable;
            connection.Close();
        }


        private void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateTimes())
                {

                    int custId = Convert.ToInt32(CustomersGrid.CurrentRow.Cells[0].Value);

                    DateTime start = DateTimeOffset.Parse(startTime.Text).UtcDateTime;
                    DateTime end = DateTimeOffset.Parse(endTime.Text).UtcDateTime;


                    string ConnectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
                    MySqlConnection connection = new MySqlConnection(ConnectionString);
                    connection.Open();

                    MySqlCommand Cmd = new MySqlCommand("INSERT INTO appointment" + "(customerId, userId, title, description, location, contact, type, url, start, end, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                                                        "VALUES(@customerId, @userId, @title, @description, @location, @contact, @type, @url, @start, @end, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)", connection);

                    Cmd.Parameters.AddWithValue("@customerId", custId);
                    Cmd.Parameters.AddWithValue("@userId", 1);
                    Cmd.Parameters.AddWithValue("@title", "");
                    Cmd.Parameters.AddWithValue("@description", "");
                    Cmd.Parameters.AddWithValue("@location", locationBox.Text);
                    Cmd.Parameters.AddWithValue("@contact", "");
                    Cmd.Parameters.AddWithValue("@type", appointmentTypeBox.Text);
                    Cmd.Parameters.AddWithValue("@url", "");
                    Cmd.Parameters.AddWithValue("@start", start);
                    Cmd.Parameters.AddWithValue("@end", end);
                    Cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
                    Cmd.Parameters.AddWithValue("@createdBy", "test");
                    Cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
                    Cmd.Parameters.AddWithValue("@lastUpdateBy", "test");

                    Cmd.ExecuteNonQuery();

                    connection.Close();

                    if (CultureInfo.CurrentCulture.LCID == 1036)
                    {
                        MessageBox.Show("Rendez-vous ajouté.");
                    }
                    else
                    {
                        MessageBox.Show("Appointment added.");
                    }
                    this.Hide();
                    WelcomeForm welcome = new WelcomeForm();
                    welcome.Show();
                }
            }
            catch
            {
                return;
            }
        }
        

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            WelcomeForm welcome = new WelcomeForm();
            welcome.Show();
        }


        private void CustomersGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
                idSelectedCustomer = e.RowIndex;
                string customer = CustomersGrid.CurrentRow.Cells[1].Value.ToString();
                CustomerTextBox.Text = customer;
                CustomerTextBox.BackColor = System.Drawing.Color.Empty;
         
        }

        private void appointmentTypeBox_SelectedIndexChanged(object sender, EventArgs e)
        {
         
           appointmentTypeBox.BackColor = System.Drawing.Color.White;


        }

        private void startTime_ValueChanged(object sender, EventArgs e)
        {
            OutsideBusinessHours();
            ValidateTimes();
            validTimes();
        }

        private void endTime_ValueChanged(object sender, EventArgs e)
        {
            OutsideBusinessHours();
            ValidateTimes();
            validTimes();
        }

        private void locationBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            locationBox.BackColor = System.Drawing.Color.White;
        }

        private void AppointmentsGrid_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value is DateTime)
            {
                var date = (DateTime)e.Value;
                var localDate = date.ToLocalTime();
                e.Value = localDate;

            }

        }
    }
}
