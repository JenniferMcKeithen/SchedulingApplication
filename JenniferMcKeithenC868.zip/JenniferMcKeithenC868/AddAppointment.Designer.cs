﻿namespace JenniferMcKeithenC969
{
    partial class AddAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CustomersGrid = new System.Windows.Forms.DataGridView();
            this.CustomersLabel = new System.Windows.Forms.Label();
            this.CustomerTextBox = new System.Windows.Forms.TextBox();
            this.CustomerName = new System.Windows.Forms.Label();
            this.startTime = new System.Windows.Forms.DateTimePicker();
            this.startLabel = new System.Windows.Forms.Label();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.Location = new System.Windows.Forms.Label();
            this.locationBox = new System.Windows.Forms.ComboBox();
            this.appointmentTypeBox = new System.Windows.Forms.ComboBox();
            this.typeLabel = new System.Windows.Forms.Label();
            this.endTime = new System.Windows.Forms.DateTimePicker();
            this.endLabel = new System.Windows.Forms.Label();
            this.messageLabel = new System.Windows.Forms.Label();
            this.AppointmentsGrid = new System.Windows.Forms.DataGridView();
            this.appoints = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.CustomersGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AppointmentsGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // CustomersGrid
            // 
            this.CustomersGrid.BackgroundColor = System.Drawing.Color.IndianRed;
            this.CustomersGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CustomersGrid.Location = new System.Drawing.Point(430, 110);
            this.CustomersGrid.Margin = new System.Windows.Forms.Padding(2);
            this.CustomersGrid.Name = "CustomersGrid";
            this.CustomersGrid.RowTemplate.Height = 28;
            this.CustomersGrid.Size = new System.Drawing.Size(465, 148);
            this.CustomersGrid.TabIndex = 0;
            this.CustomersGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CustomersGrid_CellContentClick);
            // 
            // CustomersLabel
            // 
            this.CustomersLabel.AutoSize = true;
            this.CustomersLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomersLabel.Location = new System.Drawing.Point(426, 52);
            this.CustomersLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.CustomersLabel.Name = "CustomersLabel";
            this.CustomersLabel.Size = new System.Drawing.Size(100, 18);
            this.CustomersLabel.TabIndex = 1;
            this.CustomersLabel.Text = "Customers";
            // 
            // CustomerTextBox
            // 
            this.CustomerTextBox.Enabled = false;
            this.CustomerTextBox.Location = new System.Drawing.Point(188, 48);
            this.CustomerTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.CustomerTextBox.Name = "CustomerTextBox";
            this.CustomerTextBox.Size = new System.Drawing.Size(209, 20);
            this.CustomerTextBox.TabIndex = 2;
            // 
            // CustomerName
            // 
            this.CustomerName.AutoSize = true;
            this.CustomerName.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerName.Location = new System.Drawing.Point(11, 51);
            this.CustomerName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.Size = new System.Drawing.Size(91, 18);
            this.CustomerName.TabIndex = 3;
            this.CustomerName.Text = "Customer";
            // 
            // startTime
            // 
            this.startTime.AllowDrop = true;
            this.startTime.CalendarFont = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startTime.CustomFormat = "ddd, MMM dd, yyyy hh:mm tt ";
            this.startTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.startTime.Location = new System.Drawing.Point(188, 110);
            this.startTime.Margin = new System.Windows.Forms.Padding(2);
            this.startTime.Name = "startTime";
            this.startTime.Size = new System.Drawing.Size(209, 20);
            this.startTime.TabIndex = 4;
            this.startTime.ValueChanged += new System.EventHandler(this.startTime_ValueChanged);
            // 
            // startLabel
            // 
            this.startLabel.AutoSize = true;
            this.startLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startLabel.Location = new System.Drawing.Point(11, 114);
            this.startLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.startLabel.Name = "startLabel";
            this.startLabel.Size = new System.Drawing.Size(49, 18);
            this.startLabel.TabIndex = 5;
            this.startLabel.Text = "Start";
            // 
            // SaveBtn
            // 
            this.SaveBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.SaveBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveBtn.Location = new System.Drawing.Point(188, 546);
            this.SaveBtn.Margin = new System.Windows.Forms.Padding(2);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(209, 43);
            this.SaveBtn.TabIndex = 6;
            this.SaveBtn.Text = "Save";
            this.SaveBtn.UseVisualStyleBackColor = false;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.CancelBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelBtn.Location = new System.Drawing.Point(685, 546);
            this.CancelBtn.Margin = new System.Windows.Forms.Padding(2);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(209, 43);
            this.CancelBtn.TabIndex = 7;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = false;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // Location
            // 
            this.Location.AutoSize = true;
            this.Location.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Location.Location = new System.Drawing.Point(11, 254);
            this.Location.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Location.Name = "Location";
            this.Location.Size = new System.Drawing.Size(80, 18);
            this.Location.TabIndex = 9;
            this.Location.Text = "Location";
            // 
            // locationBox
            // 
            this.locationBox.FormattingEnabled = true;
            this.locationBox.Items.AddRange(new object[] {
            "New York ",
            "Phoenix ",
            "Los Angeles ",
            "Toronto",
            "Vancouver",
            "London",
            "Oslo",
            "Paris"});
            this.locationBox.Location = new System.Drawing.Point(188, 252);
            this.locationBox.Margin = new System.Windows.Forms.Padding(2);
            this.locationBox.Name = "locationBox";
            this.locationBox.Size = new System.Drawing.Size(209, 21);
            this.locationBox.TabIndex = 10;
            this.locationBox.SelectedIndexChanged += new System.EventHandler(this.locationBox_SelectedIndexChanged);
            // 
            // appointmentTypeBox
            // 
            this.appointmentTypeBox.FormattingEnabled = true;
            this.appointmentTypeBox.Items.AddRange(new object[] {
            "Scrum",
            "Presentation",
            "One on One",
            "Follow up"});
            this.appointmentTypeBox.Location = new System.Drawing.Point(188, 339);
            this.appointmentTypeBox.Name = "appointmentTypeBox";
            this.appointmentTypeBox.Size = new System.Drawing.Size(209, 21);
            this.appointmentTypeBox.TabIndex = 11;
            this.appointmentTypeBox.SelectedIndexChanged += new System.EventHandler(this.appointmentTypeBox_SelectedIndexChanged);
            // 
            // typeLabel
            // 
            this.typeLabel.AutoSize = true;
            this.typeLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typeLabel.Location = new System.Drawing.Point(11, 341);
            this.typeLabel.Name = "typeLabel";
            this.typeLabel.Size = new System.Drawing.Size(50, 18);
            this.typeLabel.TabIndex = 12;
            this.typeLabel.Text = "Type";
            // 
            // endTime
            // 
            this.endTime.CustomFormat = "ddd, MMM dd, yyyy hh:mm tt ";
            this.endTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.endTime.Location = new System.Drawing.Point(188, 178);
            this.endTime.Name = "endTime";
            this.endTime.Size = new System.Drawing.Size(209, 20);
            this.endTime.TabIndex = 13;
            this.endTime.ValueChanged += new System.EventHandler(this.endTime_ValueChanged);
            // 
            // endLabel
            // 
            this.endLabel.AutoSize = true;
            this.endLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.endLabel.Location = new System.Drawing.Point(11, 182);
            this.endLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.endLabel.Name = "endLabel";
            this.endLabel.Size = new System.Drawing.Size(40, 18);
            this.endLabel.TabIndex = 14;
            this.endLabel.Text = "End";
            // 
            // messageLabel
            // 
            this.messageLabel.AutoSize = true;
            this.messageLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.messageLabel.Location = new System.Drawing.Point(41, 440);
            this.messageLabel.Name = "messageLabel";
            this.messageLabel.Size = new System.Drawing.Size(97, 18);
            this.messageLabel.TabIndex = 21;
            this.messageLabel.Text = "MessLabel";
            // 
            // AppointmentsGrid
            // 
            this.AppointmentsGrid.BackgroundColor = System.Drawing.Color.IndianRed;
            this.AppointmentsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AppointmentsGrid.Location = new System.Drawing.Point(429, 341);
            this.AppointmentsGrid.Margin = new System.Windows.Forms.Padding(2);
            this.AppointmentsGrid.Name = "AppointmentsGrid";
            this.AppointmentsGrid.RowTemplate.Height = 28;
            this.AppointmentsGrid.Size = new System.Drawing.Size(465, 148);
            this.AppointmentsGrid.TabIndex = 23;
            this.AppointmentsGrid.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.AppointmentsGrid_CellFormatting);
            // 
            // appoints
            // 
            this.appoints.AutoSize = true;
            this.appoints.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appoints.Location = new System.Drawing.Point(427, 295);
            this.appoints.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.appoints.Name = "appoints";
            this.appoints.Size = new System.Drawing.Size(129, 18);
            this.appoints.TabIndex = 24;
            this.appoints.Text = "Appointments";
            // 
            // AddAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1084, 661);
            this.Controls.Add(this.appoints);
            this.Controls.Add(this.AppointmentsGrid);
            this.Controls.Add(this.messageLabel);
            this.Controls.Add(this.endLabel);
            this.Controls.Add(this.endTime);
            this.Controls.Add(this.typeLabel);
            this.Controls.Add(this.appointmentTypeBox);
            this.Controls.Add(this.locationBox);
            this.Controls.Add(this.Location);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.startLabel);
            this.Controls.Add(this.startTime);
            this.Controls.Add(this.CustomerName);
            this.Controls.Add(this.CustomerTextBox);
            this.Controls.Add(this.CustomersLabel);
            this.Controls.Add(this.CustomersGrid);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(1100, 700);
            this.Name = "AddAppointment";
            this.Text = "Add Appointment";
            ((System.ComponentModel.ISupportInitialize)(this.CustomersGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AppointmentsGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView CustomersGrid;
        private System.Windows.Forms.Label CustomersLabel;
        private System.Windows.Forms.TextBox CustomerTextBox;
        private System.Windows.Forms.Label CustomerName;
        private System.Windows.Forms.DateTimePicker startTime;
        private System.Windows.Forms.Label startLabel;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.Button CancelBtn;
        private new System.Windows.Forms.Label Location;
        private System.Windows.Forms.ComboBox locationBox;
        private System.Windows.Forms.ComboBox appointmentTypeBox;
        private System.Windows.Forms.Label typeLabel;
        private System.Windows.Forms.DateTimePicker endTime;
        private System.Windows.Forms.Label endLabel;
        private System.Windows.Forms.Label messageLabel;
        private System.Windows.Forms.DataGridView AppointmentsGrid;
        private System.Windows.Forms.Label appoints;
    }
}