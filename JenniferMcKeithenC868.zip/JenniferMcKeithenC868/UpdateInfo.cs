﻿using System;
using MySql.Data.MySqlClient;
using System.Data;
using System.Collections.Generic;

public class UpdateInfo
{
	public static string loggedInUser { get; set; }

	public static int loggedInUserID { get; set; }

	public static int customerID { get; set; }

	
	public static string customerFullName { get; set; }

	public static int custAddressID { get; set; }

	public static string customerAddress { get; set; }

	public static string customerCity { get; set; }

	public static string customerCountry { get; set; }

	public static string customerPhoneNum { get; set; }


	
	public static int appointmentId { get; set; }

	public static DateTime AppointmentStartDate { get; set; }

    public static DateTime AppointmentEndDate { get; set; }

	public static DateTime AppointmentStartTime { get; set; }

	public static DateTime AppointmentEndTime { get; set; }

    public static string AppointmentLocation { get; set; }

    public static string AppointType { get; set; }

    public static int consultantID { get; set; }

	public static string consultantName { get; set; }


	public UpdateInfo(int custID, string custFullName, string custAddress, string custCity, string custCountry, string custPhoneNum)
    {
		customerID = custID;
		customerFullName = custFullName;
		customerAddress = custAddress;
		customerCity = custCity;
		customerCountry = custCountry;
		customerPhoneNum = custPhoneNum;
    }

    public UpdateInfo()
    {

    }
	
}
