﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Globalization;

namespace JenniferMcKeithenC969
{
    public partial class Add_Customer : Form
    {
        public int cityCode;
        public string zipCode;
        public string errMessage;


        private bool activateSaveBtn()
        {
            return
            ((!string.IsNullOrWhiteSpace(FNametextBox.Text)) &&
              (!string.IsNullOrWhiteSpace(LNametextBox.Text)) &&
              (!string.IsNullOrWhiteSpace(Address1Box.Text)) &&
              (!string.IsNullOrWhiteSpace(PhoneBox.Text)) &&
              (!string.IsNullOrWhiteSpace(CityBox.Text)) &&
              (!string.IsNullOrWhiteSpace(CountryBox.Text)) );
        }

        public Add_Customer()
        {
            InitializeComponent();
            messageLabel.Visible = false;

            if (CultureInfo.CurrentCulture.LCID == 1036)
            {
                FirstName.Text = "Prénom";
                LastName.Text = "Nom";
                Address1.Text = "Adresse postale";
                City.Text = "Ville";
                Country.Text = "Nom du pays";
                PhoneNum.Text = "Numéro de téléphone";
                SaveBtn.Text = "Réserver";
                CancelBtn.Text = "Annuler";
            }
        }


        private void CancelBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            WelcomeForm welcome = new WelcomeForm();
            welcome.Show();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string ConnectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
                MySqlConnection connection = new MySqlConnection(ConnectionString);
                connection.Open();

                MySqlCommand Cmd = new MySqlCommand("INSERT INTO address " + "(address, address2, cityId, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                                                    "VALUES(@address, @address2, @cityId, @postalCode, @phone, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)", connection);

                Cmd.Parameters.AddWithValue("@address", Address1Box.Text);
                Cmd.Parameters.AddWithValue("@address2", "");
                Cmd.Parameters.AddWithValue("@cityId", cityCode);
                Cmd.Parameters.AddWithValue("@postalCode", zipCode);
                Cmd.Parameters.AddWithValue("@phone", PhoneBox.Text);
                Cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
                Cmd.Parameters.AddWithValue("@createdBy", "jennifer");
                Cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
                Cmd.Parameters.AddWithValue("@lastUpdateBy", "jennifer");

                Cmd.ExecuteNonQuery();
                int addressID = (int)Cmd.LastInsertedId;

                MySqlCommand Cmd2 = new MySqlCommand("INSERT INTO customer" + "(customerName, addressId, active, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                                                   "VALUES(@customerName, @addressId, @active, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)", connection);

                Cmd2.Parameters.AddWithValue("@customerName", FNametextBox.Text + LNametextBox.Text);
                Cmd2.Parameters.AddWithValue("@addressId", addressID);
                Cmd2.Parameters.AddWithValue("@active", true);
                Cmd2.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
                Cmd2.Parameters.AddWithValue("@createdBy", "jennifer");
                Cmd2.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
                Cmd2.Parameters.AddWithValue("@lastUpdateBy", "jennifer");


                MySqlDataAdapter adapter2 = new MySqlDataAdapter(Cmd2);

                DataTable table2 = new DataTable();
                adapter2.Fill(table2);

                connection.Close();

                if (CultureInfo.CurrentCulture.LCID == 1036)
                {
                    MessageBox.Show("Client ajouté");
                }
                else
                {
                    MessageBox.Show("Customer added.");
                }

                this.Hide();
                WelcomeForm welcome = new WelcomeForm();
                welcome.Show();
            }
            catch
            {
                if (CultureInfo.CurrentCulture.LCID == 1036)
                {
                    errMessage = "Veuillez remplir le formulaire.";
                }
                else
                {
                    errMessage = "Please complete the form.";
                }
               
                messageLabel.Visible = true;
                messageLabel.ForeColor = System.Drawing.Color.Red;
                messageLabel.Text = errMessage;
                return;
               
            }
        }

        public void addCustomer()
        {
            string ConnectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(ConnectionString);
            connection.Open();

            MySqlCommand Cmd = new MySqlCommand("INSERT INTO address " + "(address, address2, cityId, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                                                "VALUES(@address, @address2, @cityId, @postalCode, @phone, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)", connection);

            Cmd.Parameters.AddWithValue("@address", "123 Testing Street");
            Cmd.Parameters.AddWithValue("@address2", "");
            Cmd.Parameters.AddWithValue("@cityId", cityCode);
            Cmd.Parameters.AddWithValue("@postalCode", zipCode);
            Cmd.Parameters.AddWithValue("@phone", PhoneBox.Text);
            Cmd.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
            Cmd.Parameters.AddWithValue("@createdBy", "jennifer");
            Cmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            Cmd.Parameters.AddWithValue("@lastUpdateBy", "jennifer");

            Cmd.ExecuteNonQuery();
            int addressID = (int)Cmd.LastInsertedId;

            MySqlCommand Cmd2 = new MySqlCommand("INSERT INTO customer" + "(customerName, addressId, active, createDate, createdBy, lastUpdate, lastUpdateBy) " +
                                               "VALUES(@customerName, @addressId, @active, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)", connection);

            Cmd2.Parameters.AddWithValue("@customerName", FNametextBox.Text + LNametextBox.Text);
            Cmd2.Parameters.AddWithValue("@addressId", addressID);
            Cmd2.Parameters.AddWithValue("@active", true);
            Cmd2.Parameters.AddWithValue("@createDate", DateTime.UtcNow);
            Cmd2.Parameters.AddWithValue("@createdBy", "jennifer");
            Cmd2.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
            Cmd2.Parameters.AddWithValue("@lastUpdateBy", "jennifer");


            MySqlDataAdapter adapter2 = new MySqlDataAdapter(Cmd2);

            DataTable table2 = new DataTable();
            adapter2.Fill(table2);

            connection.Close();
        }
     

        private void FNametextBox_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(FNametextBox.Text))
            {
                FNametextBox.BackColor = System.Drawing.Color.Salmon;
            }
            else
            {
                FNametextBox.BackColor = System.Drawing.Color.White;
            }
            SaveBtn.Enabled = activateSaveBtn();
        }

        private void LNametextBox_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LNametextBox.Text))
            {
                LNametextBox.BackColor = System.Drawing.Color.Salmon;
            }
            else
            {
                LNametextBox.BackColor = System.Drawing.Color.White;
            }
            SaveBtn.Enabled = activateSaveBtn();
        }

        private void Address1Box_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Address1Box.Text))
            {
                Address1Box.BackColor = System.Drawing.Color.Salmon;
            }
            else
            {
                Address1Box.BackColor = System.Drawing.Color.White;
            }
            SaveBtn.Enabled = activateSaveBtn();
        }


        private void PhoneBox_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PhoneBox.Text))
            {
                PhoneBox.BackColor = System.Drawing.Color.Salmon;
            }
            else
            {
                PhoneBox.BackColor = System.Drawing.Color.White;
            }
            SaveBtn.Enabled = activateSaveBtn();
        }

        private void CityBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CityBox.Text == "New York")
            {
                CountryBox.Text = "US";
                cityCode = 1;
                zipCode = "10016";
            }

            if (CityBox.Text == "Los Angeles")
            {
                CountryBox.Text = "US";
                cityCode = 2;
                zipCode = "90210";
            }

            if (CityBox.Text == "Phoenix")
            {
                CountryBox.Text = "US";
                cityCode = 7;
                zipCode = "85011";
            }

            if (CityBox.Text == "Toronto")
            {
                CountryBox.Text = "Canada";
                cityCode = 3;
                zipCode = "M4C2T9";
            }

            if (CityBox.Text == "Vancouver")
            {
                CountryBox.Text = "Canada";
                cityCode = 4;
                zipCode = "V5K1B7";
            }

            if (CityBox.Text == "Oslo")
            {
                CountryBox.Text = "Norway";
                cityCode = 5;
                zipCode = "0164";
            }

            if (CityBox.Text == "London")
            {
                CountryBox.Text = "United Kingdom";
                cityCode = 6;
                zipCode = "W1A 1AA";
            }
            if (CityBox.Text == "Paris")
            {
                CountryBox.Text = "France";
                cityCode = 8;
                zipCode = "75007";
            }


            if (string.IsNullOrWhiteSpace(CityBox.Text))
            {
                CityBox.BackColor = System.Drawing.Color.Salmon;
            }
            else
            {
                CityBox.BackColor = System.Drawing.Color.White;
            }
            SaveBtn.Enabled = activateSaveBtn();

        }

        private void CountryBox_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(CountryBox.Text))
            {
                CountryBox.BackColor = System.Drawing.Color.Salmon;
            }
            else
            {
                CountryBox.BackColor = System.Drawing.Color.White;
            }
            SaveBtn.Enabled = activateSaveBtn();
        }

        private void Country_Click(object sender, EventArgs e)
        {

        }
    }
}
