﻿namespace JenniferMcKeithenC969
{
    partial class AllAppointments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridAllAppts = new System.Windows.Forms.DataGridView();
            this.MainMenuBtn = new System.Windows.Forms.Button();
            this.radioViewMonth = new System.Windows.Forms.RadioButton();
            this.radioViewWeek = new System.Windows.Forms.RadioButton();
            this.monthCalendar = new System.Windows.Forms.MonthCalendar();
            this.alertMessage = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridAllAppts)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridAllAppts
            // 
            this.dataGridAllAppts.AllowUserToAddRows = false;
            this.dataGridAllAppts.AllowUserToDeleteRows = false;
            this.dataGridAllAppts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridAllAppts.BackgroundColor = System.Drawing.Color.IndianRed;
            this.dataGridAllAppts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridAllAppts.ColumnHeadersVisible = false;
            this.dataGridAllAppts.Location = new System.Drawing.Point(55, 50);
            this.dataGridAllAppts.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridAllAppts.Name = "dataGridAllAppts";
            this.dataGridAllAppts.RowHeadersVisible = false;
            this.dataGridAllAppts.RowTemplate.Height = 28;
            this.dataGridAllAppts.Size = new System.Drawing.Size(568, 294);
            this.dataGridAllAppts.TabIndex = 0;
            this.dataGridAllAppts.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridAllAppts_CellFormatting);
            this.dataGridAllAppts.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dataGridAllAppts_DataBindingComplete);
            // 
            // MainMenuBtn
            // 
            this.MainMenuBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.MainMenuBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuBtn.Location = new System.Drawing.Point(55, 516);
            this.MainMenuBtn.Margin = new System.Windows.Forms.Padding(2);
            this.MainMenuBtn.Name = "MainMenuBtn";
            this.MainMenuBtn.Size = new System.Drawing.Size(242, 44);
            this.MainMenuBtn.TabIndex = 3;
            this.MainMenuBtn.Text = "Main Menu";
            this.MainMenuBtn.UseVisualStyleBackColor = false;
            this.MainMenuBtn.Click += new System.EventHandler(this.MainMenuBtn_Click);
            // 
            // radioViewMonth
            // 
            this.radioViewMonth.AutoSize = true;
            this.radioViewMonth.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioViewMonth.Location = new System.Drawing.Point(471, 11);
            this.radioViewMonth.Margin = new System.Windows.Forms.Padding(2);
            this.radioViewMonth.Name = "radioViewMonth";
            this.radioViewMonth.Size = new System.Drawing.Size(152, 22);
            this.radioViewMonth.TabIndex = 4;
            this.radioViewMonth.TabStop = true;
            this.radioViewMonth.Text = "View by Month";
            this.radioViewMonth.UseVisualStyleBackColor = true;
            this.radioViewMonth.CheckedChanged += new System.EventHandler(this.radioViewMonth_CheckedChanged);
            // 
            // radioViewWeek
            // 
            this.radioViewWeek.AutoSize = true;
            this.radioViewWeek.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioViewWeek.Location = new System.Drawing.Point(55, 11);
            this.radioViewWeek.Margin = new System.Windows.Forms.Padding(2);
            this.radioViewWeek.Name = "radioViewWeek";
            this.radioViewWeek.Size = new System.Drawing.Size(143, 22);
            this.radioViewWeek.TabIndex = 5;
            this.radioViewWeek.TabStop = true;
            this.radioViewWeek.Text = "View by Week";
            this.radioViewWeek.UseVisualStyleBackColor = true;
            this.radioViewWeek.CheckedChanged += new System.EventHandler(this.radioViewWeek_CheckedChanged);
            // 
            // monthCalendar
            // 
            this.monthCalendar.Location = new System.Drawing.Point(396, 420);
            this.monthCalendar.Name = "monthCalendar";
            this.monthCalendar.TabIndex = 7;
            this.monthCalendar.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar_DateSelected);
            // 
            // alertMessage
            // 
            this.alertMessage.AutoSize = true;
            this.alertMessage.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alertMessage.Location = new System.Drawing.Point(55, 371);
            this.alertMessage.Name = "alertMessage";
            this.alertMessage.Size = new System.Drawing.Size(127, 18);
            this.alertMessage.TabIndex = 8;
            this.alertMessage.Text = "messageLabel";
            // 
            // AllAppointments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(847, 600);
            this.Controls.Add(this.alertMessage);
            this.Controls.Add(this.monthCalendar);
            this.Controls.Add(this.radioViewWeek);
            this.Controls.Add(this.radioViewMonth);
            this.Controls.Add(this.MainMenuBtn);
            this.Controls.Add(this.dataGridAllAppts);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(863, 639);
            this.Name = "AllAppointments";
            this.Text = "All Appointments";
            this.Load += new System.EventHandler(this.AllAppointments_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridAllAppts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridAllAppts;
        private System.Windows.Forms.Button MainMenuBtn;
        private System.Windows.Forms.RadioButton radioViewMonth;
        private System.Windows.Forms.RadioButton radioViewWeek;
        private System.Windows.Forms.MonthCalendar monthCalendar;
        private System.Windows.Forms.Label alertMessage;
    }
}