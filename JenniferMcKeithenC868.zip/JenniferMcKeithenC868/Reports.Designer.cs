﻿namespace JenniferMcKeithenC969
{
    partial class Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scheduleGridView = new System.Windows.Forms.DataGridView();
            this.appointTypeGrid = new System.Windows.Forms.DataGridView();
            this.appointLocationGrid = new System.Windows.Forms.DataGridView();
            this.mainMenu = new System.Windows.Forms.Button();
            this.appointmentsLabel = new System.Windows.Forms.Label();
            this.appTypeLabel = new System.Windows.Forms.Label();
            this.appLocationLabel = new System.Windows.Forms.Label();
            this.appointTypeChoose = new System.Windows.Forms.ComboBox();
            this.locationChoose = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.scheduleGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointTypeGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointLocationGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // scheduleGridView
            // 
            this.scheduleGridView.AllowUserToAddRows = false;
            this.scheduleGridView.AllowUserToDeleteRows = false;
            this.scheduleGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.scheduleGridView.BackgroundColor = System.Drawing.Color.IndianRed;
            this.scheduleGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.scheduleGridView.Location = new System.Drawing.Point(68, 62);
            this.scheduleGridView.Name = "scheduleGridView";
            this.scheduleGridView.ReadOnly = true;
            this.scheduleGridView.RowHeadersVisible = false;
            this.scheduleGridView.Size = new System.Drawing.Size(819, 149);
            this.scheduleGridView.TabIndex = 0;
            this.scheduleGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.scheduleGridView_CellFormatting);
            this.scheduleGridView.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.scheduleGridView_DataBindingComplete);
            // 
            // appointTypeGrid
            // 
            this.appointTypeGrid.AllowUserToAddRows = false;
            this.appointTypeGrid.AllowUserToDeleteRows = false;
            this.appointTypeGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.appointTypeGrid.BackgroundColor = System.Drawing.Color.IndianRed;
            this.appointTypeGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.appointTypeGrid.Location = new System.Drawing.Point(68, 270);
            this.appointTypeGrid.MinimumSize = new System.Drawing.Size(819, 149);
            this.appointTypeGrid.Name = "appointTypeGrid";
            this.appointTypeGrid.ReadOnly = true;
            this.appointTypeGrid.RowHeadersVisible = false;
            this.appointTypeGrid.Size = new System.Drawing.Size(819, 155);
            this.appointTypeGrid.TabIndex = 1;
            this.appointTypeGrid.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.appointTypeGrid_CellFormatting);
            // 
            // appointLocationGrid
            // 
            this.appointLocationGrid.AllowUserToAddRows = false;
            this.appointLocationGrid.AllowUserToDeleteRows = false;
            this.appointLocationGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.appointLocationGrid.BackgroundColor = System.Drawing.Color.IndianRed;
            this.appointLocationGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.appointLocationGrid.Location = new System.Drawing.Point(68, 485);
            this.appointLocationGrid.MinimumSize = new System.Drawing.Size(819, 149);
            this.appointLocationGrid.Name = "appointLocationGrid";
            this.appointLocationGrid.ReadOnly = true;
            this.appointLocationGrid.RowHeadersVisible = false;
            this.appointLocationGrid.Size = new System.Drawing.Size(819, 149);
            this.appointLocationGrid.TabIndex = 2;
            this.appointLocationGrid.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.appointLocationGrid_CellFormatting);
            // 
            // mainMenu
            // 
            this.mainMenu.BackColor = System.Drawing.Color.DarkKhaki;
            this.mainMenu.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mainMenu.Location = new System.Drawing.Point(624, 650);
            this.mainMenu.Name = "mainMenu";
            this.mainMenu.Size = new System.Drawing.Size(263, 62);
            this.mainMenu.TabIndex = 3;
            this.mainMenu.Text = "Main Menu";
            this.mainMenu.UseVisualStyleBackColor = false;
            this.mainMenu.Click += new System.EventHandler(this.mainMenu_Click);
            // 
            // appointmentsLabel
            // 
            this.appointmentsLabel.AutoSize = true;
            this.appointmentsLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appointmentsLabel.Location = new System.Drawing.Point(66, 27);
            this.appointmentsLabel.Name = "appointmentsLabel";
            this.appointmentsLabel.Size = new System.Drawing.Size(217, 18);
            this.appointmentsLabel.TabIndex = 4;
            this.appointmentsLabel.Text = "My Schedule This Month";
            // 
            // appTypeLabel
            // 
            this.appTypeLabel.AutoSize = true;
            this.appTypeLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appTypeLabel.Location = new System.Drawing.Point(66, 239);
            this.appTypeLabel.Name = "appTypeLabel";
            this.appTypeLabel.Size = new System.Drawing.Size(201, 18);
            this.appTypeLabel.TabIndex = 5;
            this.appTypeLabel.Text = "Appointments by Type";
            // 
            // appLocationLabel
            // 
            this.appLocationLabel.AutoSize = true;
            this.appLocationLabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appLocationLabel.Location = new System.Drawing.Point(73, 454);
            this.appLocationLabel.Name = "appLocationLabel";
            this.appLocationLabel.Size = new System.Drawing.Size(231, 18);
            this.appLocationLabel.TabIndex = 6;
            this.appLocationLabel.Text = "Appointments by Location";
            // 
            // appointTypeChoose
            // 
            this.appointTypeChoose.FormattingEnabled = true;
            this.appointTypeChoose.Items.AddRange(new object[] {
            "Scrum",
            "Presentation",
            "One on One",
            "Follow up"});
            this.appointTypeChoose.Location = new System.Drawing.Point(735, 237);
            this.appointTypeChoose.Name = "appointTypeChoose";
            this.appointTypeChoose.Size = new System.Drawing.Size(153, 21);
            this.appointTypeChoose.TabIndex = 7;
            this.appointTypeChoose.SelectedIndexChanged += new System.EventHandler(this.appointTypeChoose_SelectedIndexChanged);
            // 
            // locationChoose
            // 
            this.locationChoose.FormattingEnabled = true;
            this.locationChoose.Items.AddRange(new object[] {
            "New York",
            "Phoenix",
            "Los Angeles",
            "Toronto",
            "Vancouver",
            "London",
            "Oslo",
            "Paris"});
            this.locationChoose.Location = new System.Drawing.Point(735, 447);
            this.locationChoose.Name = "locationChoose";
            this.locationChoose.Size = new System.Drawing.Size(153, 21);
            this.locationChoose.TabIndex = 8;
            this.locationChoose.SelectedIndexChanged += new System.EventHandler(this.locationChoose_SelectedIndexChanged);
            // 
            // Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(985, 801);
            this.Controls.Add(this.locationChoose);
            this.Controls.Add(this.appointTypeChoose);
            this.Controls.Add(this.appLocationLabel);
            this.Controls.Add(this.appTypeLabel);
            this.Controls.Add(this.appointmentsLabel);
            this.Controls.Add(this.mainMenu);
            this.Controls.Add(this.appointLocationGrid);
            this.Controls.Add(this.appointTypeGrid);
            this.Controls.Add(this.scheduleGridView);
            this.MinimumSize = new System.Drawing.Size(1001, 840);
            this.Name = "Reports";
            this.Text = "Reports";
            ((System.ComponentModel.ISupportInitialize)(this.scheduleGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointTypeGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointLocationGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView scheduleGridView;
        private System.Windows.Forms.DataGridView appointTypeGrid;
        private System.Windows.Forms.DataGridView appointLocationGrid;
        private System.Windows.Forms.Button mainMenu;
        private System.Windows.Forms.Label appointmentsLabel;
        private System.Windows.Forms.Label appTypeLabel;
        private System.Windows.Forms.Label appLocationLabel;
        private System.Windows.Forms.ComboBox appointTypeChoose;
        private System.Windows.Forms.ComboBox locationChoose;
    }
}