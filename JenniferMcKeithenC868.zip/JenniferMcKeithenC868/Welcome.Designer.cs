﻿namespace JenniferMcKeithenC969
{
    partial class WelcomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeHeader = new System.Windows.Forms.Label();
            this.customerGridView = new System.Windows.Forms.DataGridView();
            this.CustomerLabel = new System.Windows.Forms.Label();
            this.addCustBtn = new System.Windows.Forms.Button();
            this.AppointmentsGrid = new System.Windows.Forms.DataGridView();
            this.myAppointments = new System.Windows.Forms.Label();
            this.addAppointmentBtn = new System.Windows.Forms.Button();
            this.byWeekLink = new System.Windows.Forms.LinkLabel();
            this.updateCustBtn = new System.Windows.Forms.Button();
            this.deleteCustBtn = new System.Windows.Forms.Button();
            this.updateApptBtn = new System.Windows.Forms.Button();
            this.deleteApptBtn = new System.Windows.Forms.Button();
            this.ExitAppBtn = new System.Windows.Forms.Button();
            this.appointNotification = new System.Windows.Forms.Label();
            this.reportsButton = new System.Windows.Forms.Button();
            this.searchCustomerBox = new System.Windows.Forms.TextBox();
            this.searchCustBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.customerGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AppointmentsGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // WelcomeHeader
            // 
            this.WelcomeHeader.AutoSize = true;
            this.WelcomeHeader.Font = new System.Drawing.Font("Lucida Fax", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WelcomeHeader.Location = new System.Drawing.Point(23, 24);
            this.WelcomeHeader.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.WelcomeHeader.Name = "WelcomeHeader";
            this.WelcomeHeader.Size = new System.Drawing.Size(241, 32);
            this.WelcomeHeader.TabIndex = 0;
            this.WelcomeHeader.Text = "Welcome, Dave!";
            // 
            // customerGridView
            // 
            this.customerGridView.AllowUserToAddRows = false;
            this.customerGridView.AllowUserToDeleteRows = false;
            this.customerGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.customerGridView.BackgroundColor = System.Drawing.Color.IndianRed;
            this.customerGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customerGridView.Location = new System.Drawing.Point(88, 119);
            this.customerGridView.Margin = new System.Windows.Forms.Padding(2);
            this.customerGridView.Name = "customerGridView";
            this.customerGridView.ReadOnly = true;
            this.customerGridView.RowHeadersVisible = false;
            this.customerGridView.RowTemplate.Height = 28;
            this.customerGridView.Size = new System.Drawing.Size(819, 176);
            this.customerGridView.TabIndex = 1;
            this.customerGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.customerGridView_CellContentClick);
            // 
            // CustomerLabel
            // 
            this.CustomerLabel.AutoSize = true;
            this.CustomerLabel.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerLabel.Location = new System.Drawing.Point(85, 83);
            this.CustomerLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.CustomerLabel.Name = "CustomerLabel";
            this.CustomerLabel.Size = new System.Drawing.Size(130, 24);
            this.CustomerLabel.TabIndex = 2;
            this.CustomerLabel.Text = "Customers";
            // 
            // addCustBtn
            // 
            this.addCustBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.addCustBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addCustBtn.Location = new System.Drawing.Point(89, 313);
            this.addCustBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addCustBtn.Name = "addCustBtn";
            this.addCustBtn.Size = new System.Drawing.Size(243, 49);
            this.addCustBtn.TabIndex = 3;
            this.addCustBtn.Text = "Add Customer";
            this.addCustBtn.UseVisualStyleBackColor = false;
            this.addCustBtn.Click += new System.EventHandler(this.addCustBtn_Click);
            // 
            // AppointmentsGrid
            // 
            this.AppointmentsGrid.AllowUserToAddRows = false;
            this.AppointmentsGrid.AllowUserToDeleteRows = false;
            this.AppointmentsGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.AppointmentsGrid.BackgroundColor = System.Drawing.Color.IndianRed;
            this.AppointmentsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AppointmentsGrid.Location = new System.Drawing.Point(88, 435);
            this.AppointmentsGrid.Margin = new System.Windows.Forms.Padding(2);
            this.AppointmentsGrid.Name = "AppointmentsGrid";
            this.AppointmentsGrid.ReadOnly = true;
            this.AppointmentsGrid.RowHeadersVisible = false;
            this.AppointmentsGrid.RowTemplate.Height = 28;
            this.AppointmentsGrid.Size = new System.Drawing.Size(819, 172);
            this.AppointmentsGrid.TabIndex = 4;
            this.AppointmentsGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AppointmentsGrid_CellContentClick);
            this.AppointmentsGrid.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.AppointmentsGrid_CellFormatting);
            // 
            // myAppointments
            // 
            this.myAppointments.AutoSize = true;
            this.myAppointments.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myAppointments.Location = new System.Drawing.Point(85, 399);
            this.myAppointments.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.myAppointments.Name = "myAppointments";
            this.myAppointments.Size = new System.Drawing.Size(167, 24);
            this.myAppointments.TabIndex = 5;
            this.myAppointments.Text = "Appointments";
            // 
            // addAppointmentBtn
            // 
            this.addAppointmentBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.addAppointmentBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addAppointmentBtn.Location = new System.Drawing.Point(88, 636);
            this.addAppointmentBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addAppointmentBtn.Name = "addAppointmentBtn";
            this.addAppointmentBtn.Size = new System.Drawing.Size(243, 63);
            this.addAppointmentBtn.TabIndex = 6;
            this.addAppointmentBtn.Text = "Add Appointment";
            this.addAppointmentBtn.UseVisualStyleBackColor = false;
            this.addAppointmentBtn.Click += new System.EventHandler(this.addAppointmentBtn_Click);
            // 
            // byWeekLink
            // 
            this.byWeekLink.AutoSize = true;
            this.byWeekLink.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.byWeekLink.Location = new System.Drawing.Point(783, 399);
            this.byWeekLink.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.byWeekLink.Name = "byWeekLink";
            this.byWeekLink.Size = new System.Drawing.Size(124, 18);
            this.byWeekLink.TabIndex = 8;
            this.byWeekLink.TabStop = true;
            this.byWeekLink.Text = "View Calendar";
            this.byWeekLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.byWeekLink_LinkClicked);
            // 
            // updateCustBtn
            // 
            this.updateCustBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.updateCustBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateCustBtn.Location = new System.Drawing.Point(377, 313);
            this.updateCustBtn.Margin = new System.Windows.Forms.Padding(2);
            this.updateCustBtn.Name = "updateCustBtn";
            this.updateCustBtn.Size = new System.Drawing.Size(243, 49);
            this.updateCustBtn.TabIndex = 11;
            this.updateCustBtn.Text = "Update Customer";
            this.updateCustBtn.UseVisualStyleBackColor = false;
            this.updateCustBtn.Click += new System.EventHandler(this.updateCustBtn_Click);
            // 
            // deleteCustBtn
            // 
            this.deleteCustBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.deleteCustBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteCustBtn.Location = new System.Drawing.Point(664, 313);
            this.deleteCustBtn.Margin = new System.Windows.Forms.Padding(2);
            this.deleteCustBtn.Name = "deleteCustBtn";
            this.deleteCustBtn.Size = new System.Drawing.Size(243, 49);
            this.deleteCustBtn.TabIndex = 12;
            this.deleteCustBtn.Text = "Delete Customer";
            this.deleteCustBtn.UseVisualStyleBackColor = false;
            this.deleteCustBtn.Click += new System.EventHandler(this.deleteCustBtn_Click);
            // 
            // updateApptBtn
            // 
            this.updateApptBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.updateApptBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateApptBtn.Location = new System.Drawing.Point(377, 637);
            this.updateApptBtn.Margin = new System.Windows.Forms.Padding(2);
            this.updateApptBtn.Name = "updateApptBtn";
            this.updateApptBtn.Size = new System.Drawing.Size(243, 63);
            this.updateApptBtn.TabIndex = 13;
            this.updateApptBtn.Text = "Update Appointment";
            this.updateApptBtn.UseVisualStyleBackColor = false;
            this.updateApptBtn.Click += new System.EventHandler(this.updateApptBtn_Click);
            // 
            // deleteApptBtn
            // 
            this.deleteApptBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.deleteApptBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteApptBtn.Location = new System.Drawing.Point(664, 637);
            this.deleteApptBtn.Margin = new System.Windows.Forms.Padding(2);
            this.deleteApptBtn.Name = "deleteApptBtn";
            this.deleteApptBtn.Size = new System.Drawing.Size(243, 63);
            this.deleteApptBtn.TabIndex = 14;
            this.deleteApptBtn.Text = "Delete Appointment";
            this.deleteApptBtn.UseVisualStyleBackColor = false;
            this.deleteApptBtn.Click += new System.EventHandler(this.deleteApptBtn_Click);
            // 
            // ExitAppBtn
            // 
            this.ExitAppBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.ExitAppBtn.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitAppBtn.Location = new System.Drawing.Point(996, 642);
            this.ExitAppBtn.Margin = new System.Windows.Forms.Padding(2);
            this.ExitAppBtn.Name = "ExitAppBtn";
            this.ExitAppBtn.Size = new System.Drawing.Size(176, 58);
            this.ExitAppBtn.TabIndex = 15;
            this.ExitAppBtn.Text = "Exit";
            this.ExitAppBtn.UseVisualStyleBackColor = false;
            this.ExitAppBtn.Click += new System.EventHandler(this.ExitAppBtn_Click);
            // 
            // appointNotification
            // 
            this.appointNotification.AutoSize = true;
            this.appointNotification.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appointNotification.Location = new System.Drawing.Point(295, 28);
            this.appointNotification.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.appointNotification.Name = "appointNotification";
            this.appointNotification.Size = new System.Drawing.Size(286, 24);
            this.appointNotification.TabIndex = 16;
            this.appointNotification.Text = "appointment notification";
            // 
            // reportsButton
            // 
            this.reportsButton.BackColor = System.Drawing.Color.DarkKhaki;
            this.reportsButton.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reportsButton.Location = new System.Drawing.Point(996, 479);
            this.reportsButton.Margin = new System.Windows.Forms.Padding(2);
            this.reportsButton.Name = "reportsButton";
            this.reportsButton.Size = new System.Drawing.Size(176, 58);
            this.reportsButton.TabIndex = 17;
            this.reportsButton.Text = "View Reports";
            this.reportsButton.UseVisualStyleBackColor = false;
            this.reportsButton.Click += new System.EventHandler(this.reportsButton_Click);
            // 
            // searchCustomerBox
            // 
            this.searchCustomerBox.Location = new System.Drawing.Point(965, 119);
            this.searchCustomerBox.Name = "searchCustomerBox";
            this.searchCustomerBox.Size = new System.Drawing.Size(207, 20);
            this.searchCustomerBox.TabIndex = 18;
            // 
            // searchCustBtn
            // 
            this.searchCustBtn.BackColor = System.Drawing.Color.DarkKhaki;
            this.searchCustBtn.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchCustBtn.Location = new System.Drawing.Point(996, 165);
            this.searchCustBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchCustBtn.Name = "searchCustBtn";
            this.searchCustBtn.Size = new System.Drawing.Size(176, 44);
            this.searchCustBtn.TabIndex = 19;
            this.searchCustBtn.Text = "Search";
            this.searchCustBtn.UseVisualStyleBackColor = false;
            this.searchCustBtn.Click += new System.EventHandler(this.searchCustBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(961, 790);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 20);
            this.label1.TabIndex = 20;
            this.label1.Text = "Hyborian Systems, Inc.";
            // 
            // WelcomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1224, 830);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.searchCustBtn);
            this.Controls.Add(this.searchCustomerBox);
            this.Controls.Add(this.reportsButton);
            this.Controls.Add(this.appointNotification);
            this.Controls.Add(this.ExitAppBtn);
            this.Controls.Add(this.deleteApptBtn);
            this.Controls.Add(this.updateApptBtn);
            this.Controls.Add(this.deleteCustBtn);
            this.Controls.Add(this.updateCustBtn);
            this.Controls.Add(this.byWeekLink);
            this.Controls.Add(this.addAppointmentBtn);
            this.Controls.Add(this.myAppointments);
            this.Controls.Add(this.AppointmentsGrid);
            this.Controls.Add(this.addCustBtn);
            this.Controls.Add(this.CustomerLabel);
            this.Controls.Add(this.customerGridView);
            this.Controls.Add(this.WelcomeHeader);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(1240, 869);
            this.Name = "WelcomeForm";
            this.Text = "Welcome";
            this.Load += new System.EventHandler(this.WelcomeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customerGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AppointmentsGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WelcomeHeader;
        private System.Windows.Forms.DataGridView customerGridView;
        private System.Windows.Forms.Label CustomerLabel;
        private System.Windows.Forms.Button addCustBtn;
        private System.Windows.Forms.DataGridView AppointmentsGrid;
        private System.Windows.Forms.Label myAppointments;
        private System.Windows.Forms.Button addAppointmentBtn;
        private System.Windows.Forms.LinkLabel byWeekLink;
        private System.Windows.Forms.Button updateCustBtn;
        private System.Windows.Forms.Button deleteCustBtn;
        private System.Windows.Forms.Button updateApptBtn;
        private System.Windows.Forms.Button deleteApptBtn;
        private System.Windows.Forms.Button ExitAppBtn;
        private System.Windows.Forms.Label appointNotification;
        private System.Windows.Forms.Button reportsButton;
        private System.Windows.Forms.TextBox searchCustomerBox;
        private System.Windows.Forms.Button searchCustBtn;
        private System.Windows.Forms.Label label1;
    }
}