﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Globalization;
using MySql.Data.Types;

namespace JenniferMcKeithenC969
{
    public partial class UpdateAppointment : Form
    {
        public int idSelectedCustomer1;
        public int idSelectedConsultant1;


        public UpdateAppointment()
        {
            InitializeComponent();
            PopulateCustomers();
            PopulateAppointments();
           
            customerDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;


            appointIDBox.Text = UpdateInfo.appointmentId.ToString();
            custBox.Text = UpdateInfo.customerFullName;
            LocationMenu.Text = UpdateInfo.AppointmentLocation;
            AppointType.Text = UpdateInfo.AppointType;
            startDatePicker.Text = Convert.ToDateTime(UpdateInfo.AppointmentStartDate.ToLocalTime()).ToString();
            endDatePicker.Text = Convert.ToDateTime(UpdateInfo.AppointmentEndDate.ToLocalTime()).ToString();
           
            messageLabel.Visible = false;

            if (CultureInfo.CurrentCulture.LCID == 1036)
            {
                customerLabel.Text = "Client";
                startLabel.Text = "Début";
                endLabel.Text = "Fin";
                locationLabel.Text = "Ville";
                typeLabel.Text = "Catégorie";
                CustomersLabel.Text = "Clients";
                AppointmentsLabel.Text = "Rendez-vous";
                SaveBtn.Text = "Réserver";
                CancelBtn.Text = "Annuler";
            }


        }



        private bool appointOverlap(DateTime sta, DateTime en, DateTime appointSt, DateTime appointEn)
        {
            if (sta < appointSt)
            {
                if (en < appointSt)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                if (sta > appointEn)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        private void OutsideBusinessHours()
        {
            DateTime openingTime = DateTime.Today.AddHours(8);
            DateTime closingTime = DateTime.Today.AddHours(17);

            if ((startDatePicker.Value.TimeOfDay < openingTime.TimeOfDay) || (startDatePicker.Value.TimeOfDay > closingTime.TimeOfDay) || (endDatePicker.Value.TimeOfDay > closingTime.TimeOfDay) || (endDatePicker.Value.TimeOfDay < openingTime.TimeOfDay))
            {
                messageLabel.Visible = true;
                if (CultureInfo.CurrentCulture.LCID == 1036)
                {
                    messageLabel.Text = "Veuillez sélectionner une heure entre les heures d'ouverture, de 9 h à 17 h.";
                }
                else
                {
                    messageLabel.Text = "Please select a time between business hours, 9am and 5pm.";
                }
                SaveBtn.Enabled = false;
            }
            else
            {
                messageLabel.Visible = false;
                SaveBtn.Enabled = true;
            }

        }

        private void validTimes()
        {
            if (startDatePicker.Value.TimeOfDay > endDatePicker.Value.TimeOfDay || endDatePicker.Value.TimeOfDay < startDatePicker.Value.TimeOfDay)
            {
                messageLabel.Visible = true;

                if (CultureInfo.CurrentCulture.LCID == 1036)
                {
                    messageLabel.Text = "Veuillez sélectionner des heures valides.";
                }
                else 
                {
                    messageLabel.Text = "Please select valid times."; 
                 }
                SaveBtn.Enabled = false;
            }

        }

        private bool ValidateTimes()
        {

            string connectionString;
            connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(connectionString);

            string sqlQuery = "SELECT appointmentId, start, end FROM appointment";

            MySqlCommand command = new MySqlCommand(sqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable appointmentCheckTable = new DataTable();
            adapter.Fill(appointmentCheckTable);

            for (int idx = 0; idx < appointmentCheckTable.Rows.Count; idx++)
            {
                DateTime schedStart = TimeZoneInfo.ConvertTimeFromUtc((DateTime)appointmentCheckTable.Rows[idx]["start"], TimeZoneInfo.Local);
                DateTime schedEnd = TimeZoneInfo.ConvertTimeFromUtc((DateTime)appointmentCheckTable.Rows[idx]["end"], TimeZoneInfo.Local);
                DateTime myStart = startDatePicker.Value;
                DateTime myEnd = endDatePicker.Value;

                if ((startDatePicker.Value != schedStart) && (endDatePicker.Value != schedEnd))
                {
                    if (appointOverlap(schedStart, schedEnd, myStart, myEnd))
                    {
                        if (CultureInfo.CurrentCulture.LCID == 1036)
                        { 
                            messageLabel.Text = "Les heures / dates sélectionnées se chevauchent avec un rendez-vous existant.";
                        }
                        else
                        {
                            messageLabel.Text = "Times/Dates selected overlap with an existing appointment";
                        }

                        messageLabel.ForeColor = System.Drawing.Color.Red;
                        messageLabel.Visible = true;
                        SaveBtn.Enabled = false;
                        return true;
                    }
                }
                
            }

            connection.Close();
            return false;
        }

        private void PopulateCustomers()
        {
            string connectionString;
            connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(connectionString);

            string sqlQuery = "SELECT customer.customerId, customer.customerName, address.address, address.phone, city.city FROM customer INNER JOIN address ON customer.addressID=address.addressID INNER JOIN city ON address.cityId=city.cityId";

            MySqlCommand command = new MySqlCommand(sqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable appointmentTable = new DataTable();
            adapter.Fill(appointmentTable);
            customerDataGrid.DataSource = appointmentTable;
            connection.Close();
        }

        private void PopulateAppointments()
        {
            string connectionString;
            DataTable appointmentTable = new DataTable();
            connectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(connectionString);

            string sqlQuery = "SELECT appointment.appointmentId, customer.customerName, appointment.location, appointment.type, appointment.start, appointment.end, user.userName FROM customer INNER JOIN appointment ON customer.customerId=appointment.customerId INNER JOIN user ON appointment.userId=user.userId";

            MySqlCommand command = new MySqlCommand(sqlQuery, connection);
            connection.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);

            adapter.Fill(appointmentTable);
            AppointmentsGrid.DataSource = appointmentTable;
            connection.Close();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateTimes())
                {

                    int customerId = (int)customerDataGrid.CurrentRow.Cells[0].Value;
                    UpdateInfo.appointmentId = Convert.ToInt32(appointIDBox.Text);
                    DateTime start = DateTimeOffset.Parse(startDatePicker.Text).UtcDateTime;
                    DateTime end = DateTimeOffset.Parse(endDatePicker.Text).UtcDateTime;


                    string ConnectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
                    MySqlConnection connection = new MySqlConnection(ConnectionString);
                    string updateAppoint = "UPDATE `appointment` SET `customerId` = '" + customerId + "', `userId` = 1, `start` = '" + start.ToString("yyyy-MM-dd H:mm:ss") + "', `end` = '" + end.ToString("yyyy-MM-dd H:mm:ss") + "', `location` = '" + LocationMenu.Text + "', `type` = '" + AppointType.Text + "', `lastUpdateBy` = 'jennifer' WHERE `appointmentId` = '" + appointIDBox.Text + "'";
                    MySqlCommand comd = new MySqlCommand(updateAppoint, connection);
                    connection.Open();
                    MySqlDataReader dataReader;
                    MySqlDataAdapter adapter = new MySqlDataAdapter(comd);

                    dataReader = comd.ExecuteReader();
                    connection.Close();

                    if (CultureInfo.CurrentCulture.LCID == 1036)
                    {
                        MessageBox.Show("Rendez-vous mis à jour");
                    }
                    else
                    {
                        MessageBox.Show("Appointment updated.");
                    }
                    this.Hide();
                    WelcomeForm welcome = new WelcomeForm();
                    welcome.Show();
                }
            }
            catch
            {
                return;
            }
        }

            private void CancelBtn_Click(object sender, EventArgs e)
            {
                this.Hide();
                WelcomeForm welcome = new WelcomeForm();
                welcome.Show();
            }

            private void customerDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
            {
                idSelectedCustomer1 = e.RowIndex;
                string customer = customerDataGrid.CurrentRow.Cells[1].Value.ToString();
                custBox.Text = customer;
            }
        


        private void startDatePicker_ValueChanged(object sender, EventArgs e)
        {
            ValidateTimes();
            OutsideBusinessHours();
            validTimes();
        }

        private void endDatePicker_ValueChanged(object sender, EventArgs e)
        {
            ValidateTimes();
            OutsideBusinessHours();
            validTimes();
        }

        private void AppointmentsGrid_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value is DateTime)
            {
                var date = (DateTime)e.Value;
                var localDate = date.ToLocalTime();
                e.Value = localDate;

            }

        }
    }



}
