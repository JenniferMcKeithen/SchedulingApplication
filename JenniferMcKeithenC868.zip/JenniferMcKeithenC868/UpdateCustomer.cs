﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Globalization;

namespace JenniferMcKeithenC969
{
    public partial class UpdateCustomer : Form
    {

        int cityCode;
        string zipCode;
        int custAddId;

        private bool activateSaveBtn()
        {
            return
            ((!string.IsNullOrWhiteSpace(NameBox.Text)) &&
              (!string.IsNullOrWhiteSpace(AddressBox.Text)) &&
              (!string.IsNullOrWhiteSpace(PhoneBox.Text)) &&
              (!string.IsNullOrWhiteSpace(CityDropDown.Text)));
        }

        public UpdateCustomer()
        {
            InitializeComponent();

            int customerID = UpdateInfo.customerID;
            IDtextBox.Text = customerID.ToString();
            NameBox.Text = UpdateInfo.customerFullName;
            custAddId = UpdateInfo.custAddressID;
            AddressBox.Text = UpdateInfo.customerAddress;
            CityDropDown.SelectedItem = UpdateInfo.customerCity;
            PhoneBox.Text = UpdateInfo.customerPhoneNum;

            if (CultureInfo.CurrentCulture.LCID == 1036)
            {
                FirstName.Text = "Nom";
                addressLabel.Text = "Adresse postale";
                cityLabel.Text = "Ville";
                countryLabel.Text = "Nom du pays";
                phoneLabel.Text = "Numéro de téléphone";
                SaveBtn.Text = "Réserver";
                cancelBtn.Text = "Annuler";
            }

        }

        private void setCountry (string city)
        {

            if (city == "New York")
            {
                CountryBox.Text = "US";
                cityCode = 1;
                zipCode = "10016";
            }

            if (city == "Los Angeles")
            {
                CountryBox.Text = "US";
                cityCode = 2;
                zipCode = "90210";
            }

            if (city == "Phoenix")
            {
                CountryBox.Text = "US";
                cityCode = 7;
                zipCode = "85011";
            }

            if (city == "Toronoto")
            {
                CountryBox.Text = "Canada";
                cityCode = 3;
                zipCode = "M4C2T9";
            }

            if (city == "Vancouver")
            {
                CountryBox.Text = "Canada";
                cityCode = 4;
                zipCode = "V5K1B7";
            }

            if (city == "Oslo")
            {
                CountryBox.Text = "Norway";
                cityCode = 5;
                zipCode = "0164";
            }

            if (city == "London")
            {
                CountryBox.Text = "United Kingdom";
                cityCode = 6;
                zipCode = "W1A 1AA";
            }

            if (city == "Paris")
            {
                CountryBox.Text = "France";
                cityCode = 8;
                zipCode = "75007";
            }
            
        }

        private void NameBox_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NameBox.Text))
            {
                NameBox.BackColor = System.Drawing.Color.Salmon;
            }
            else
            {
                NameBox.BackColor = System.Drawing.Color.White;
            }
            SaveBtn.Enabled = activateSaveBtn();
        }

        private void AddressBox_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(AddressBox.Text))
            {
                AddressBox.BackColor = System.Drawing.Color.Salmon;
            }
            else
            {
                AddressBox.BackColor = System.Drawing.Color.White;
            }
            SaveBtn.Enabled = activateSaveBtn();
        }

        private void PhoneBox_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PhoneBox.Text))
            {
                PhoneBox.BackColor = System.Drawing.Color.Salmon;
            }
            else
            {
                PhoneBox.BackColor = System.Drawing.Color.White;
            }
            SaveBtn.Enabled = activateSaveBtn();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            setCountry(CityDropDown.Text);
            
            string ConnectionString = ConfigurationManager.ConnectionStrings["WGU969database"].ConnectionString;
            MySqlConnection connection = new MySqlConnection(ConnectionString);
            string updateCust = "UPDATE `customer` SET `customerName` = '" + NameBox.Text + "', `lastUpdateBy` = 'jennifer' WHERE `customerId` = '" + IDtextBox.Text + "'";
            MySqlCommand comd = new MySqlCommand(updateCust, connection);
            connection.Open();
            MySqlDataReader dataReader;
            MySqlDataAdapter adapter = new MySqlDataAdapter(comd);

            DataTable table = new DataTable();
            adapter.Fill(table);
            dataReader = comd.ExecuteReader();
            connection.Close();

            MySqlConnection connection2 = new MySqlConnection(ConnectionString);

            string updateAdd = "UPDATE `address` SET `address` = '" + AddressBox.Text + "', `cityId` = '" + cityCode + "', `postalCode` = '" + zipCode + "', `phone` ='" + PhoneBox.Text +"', `lastUpdateBy` = 'jennifer' WHERE addressId ='" + custAddId + "'";
            MySqlCommand comd2 = new MySqlCommand(updateAdd, connection2);
            connection2.Open();
            MySqlDataReader dataReader2;
            MySqlDataAdapter adapter2 = new MySqlDataAdapter(comd2);
            DataTable table2 = new DataTable();
            adapter2.Fill(table2);
            dataReader2 = comd2.ExecuteReader();

            connection.Close();

            if (CultureInfo.CurrentCulture.LCID == 1036)
            {
                MessageBox.Show("Informations client mises à jour.");
            }
            else
            {
                MessageBox.Show("Customer information updated.");
            }

            this.Hide();
            WelcomeForm welcome = new WelcomeForm();
            welcome.Show();
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            WelcomeForm welcome = new WelcomeForm();
            welcome.Show();
        }

        private void CityDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            setCountry(CityDropDown.Text);
        }

        private void CountryBox_TextChanged(object sender, EventArgs e)
        {
            setCountry(CityDropDown.Text);
        }
    }
}
